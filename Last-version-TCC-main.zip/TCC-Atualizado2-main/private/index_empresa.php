<?php
session_start();
if (!isset($_SESSION["usuario_logado"])) {
  header("Location: ../home.php");
}
require("../database/funcoes.php");
$id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
$lista_servico = ListarServicos($id_empresa);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head -->
    <?php include("templates/linkshead.php"); ?>

    <!-- Titulo da Página -->
    <title>AutoMecanica</title>
</head>

<body>
    <div class="empresa">
        <!-- Código inserindo a barra de navegação -->
        <?php include("templates/navbarEmpresa.php"); ?>
        <!-- Fim da Barra de Navegação -->
        <div id="inicio" class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="card bg-dark shadow-5-strong mt-3 m-3 rounded-5 text-white border border-dark border-5">
                        <div class="card-header mt-2">
                           <center>
                            <a class="text-center" href="index_empresa.php"><img class="text-center" src="../assets/img/logo.png" widht="50" height="50"></a>
                          </center> 
                            <div class="card-body text-center">
                                <a class="nav-link dropdown mt-1" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="https://via.placeholder.com/15x15" height="90" width="90" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="perfil_alterar_empresa.php"><i class="fa-solid fa-pen-to-square"></i> Editar Perfil </a>
                                </div>
                            </div>
                            <div class="card-footer text-center">
                                <p class="text-white">Bem vindo(a) <b><?= $_SESSION["usuario_logado"]["nome_empresa"] ?>!</b></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card bg-dark shadow-5-strong mt-3 m-3 rounded-5 text-white border border-dark border-5">
                        <div class="card-header text-center">
                            <h5><i class="fas fa-triangle-exclamation"></i> Serviços Pendentes <i class="fas fa-triangle-exclamation"></i></h5>
                        </div>
                        <div class="card-body mt-2">
                            <table class="table table-hover table-dark" id="tabela_estoque">
                                <thead>
                                    <th><b>Nome do Cliente</b></th>
                                    <th><b>Modelo do veiculo / Placa</b></th>
                                    <th><b>Situação</b></th>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($lista_servico as $item) :
                                    ?>
                                        <td class="text-white opacity-70"><?= $item["nome_cliente_empresa"] ?></td>
                                        <td class="text-white opacity-70"><?= $item["modelo_veiculo"] ?>, <?= $item["placa_veiculo"] ?></td>
                                        <td class="text-white opacity-90"><?= $item["situacao_descricao"] ?></td>
                                    <?php
                                    endforeach;
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
  </div>
</body>
</html>
