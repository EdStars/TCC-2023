<?php
session_start();
if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../index.php");
}
require("../database/funcoes.php");
$id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
$lista_ordem_servico = MostrarOrdemServico($id_empresa);
$lista_servico = ListarServicos($id_empresa);
require("../utils/mensagens.php");
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
    <!-- Titulo da Página -->
    <title>AutoMecanica</title>

</head>

<body>
<div class="empresa">
    <!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>
    <?php
            exibirMsg();
    ?>
    <div class="container">
        <div class="row bg-dark shadow-3-strong">
            <a class="text-white text-decoration-none btn btn-lg shadow-3-lg p-3" href="index_empresa.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
            <a class="btn shadow-3-lg text-decoration-none" href="formulario_os_adicionar.php"><i class="fa-solid fa-circle-plus text-white p-2"></i><b class="text-white">Nova Ordem de Serviço</b></a>

            <h3 class="text-white mt-3"> Listar Serviços </h3>
            <p class="text-white opacity-70"> Clique no nome do cliente para abrir o serviço desejado, clique no lápis para realizar alterações no serviço </p>
            <?php
            $index = 0; // Variável para criar IDs únicos para os colapsos
            foreach ($lista_servico as $item) :
                $index++;
                $collapseId = "collapseExample" . $index; // ID único para o colapso
                ?>
                <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 mt-3">
                    <p class="d-inline-flex gap-1" style="width: 100% !important">
                        <a class="btn btn-small btn-dark text-white shadow-3-strong" data-bs-toggle="collapse" href="#<?= $collapseId ?>" role="button" aria-expanded="false" aria-controls="<?= $collapseId ?>" style="width: 100%">
                            <i class="fas fa-user-tag"></i> <?= $item["nome_cliente_empresa"] ?>
                        </a>
                    </p>
                    <div class="collapse bg-dark shadow-3-strong" id="<?= $collapseId ?>">
                        <div class="card card-body bg-dark text-white shadow-3-strong p-2 mb-3 border-1 border">
                            <div class="text-center">
                                <p scope="col"><i class="fas fa-car-rear" style="margin-right: 8px"></i><b><?= $item["modelo_veiculo"] ?></b></p>
                                <p scope="col"><i class="fas fa-clipboard-list" style="margin-right: 8px"></i><b><?= $item["placa_veiculo"] ?></b></p>
                                <p scope="col"><i class="far fa-pen-to-square" style="margin-right: 8px"></i><b><?= $item["modificacoes_servico"] ?></b></p>
                                <p scope="col"><i class="far fa-pen-to-square" style="margin-right: 8px"></i><b><?= $item["situacao_descricao"] ?></b></p>
                                <p scope="col"><i class="far fa-pen-to-square" style="margin-right: 8px"></i><b><?= $item["descricao_problema_cliente"] ?></b></p>
                                <p><a class="btn btn-smaill shadow-3-strong btn-outline-dark text-white" href="formulario_servico_alterar.php?id_servico=<?= $item['id_servico'] ?>"> <i class="fa-solid fa-pencil"></i> Alterar</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            endforeach
            ?>
            <br><br>
            <div class="shadow-3-strong">
                <h3 class="text-white mt-3"> Listar Ordens de Serviço </h3>
                <p class="text-white opacity-70"> Aqui serão listadas as ordens de serviço abertas que estão aguardando a confirmação (caso não esteja, o cliente recusou ou já aceitou) </p>

                <table class=" col-12 table table-hover table-dark" id="tabela_estoque">
                    <div class="d-flex">
                        <thead class="thead-dark">
                        <tr class="text-center">
                            <th scope="col"><i class="fa-solid fa-wrench"></i> Nome do cliente</th>
                            <th scope="col"><i class=""></i>Modelo do Veiculo</th>
                            <th scope="col"><i class=""></i>Placa do Veiculo</th>
                            <th scope="col"><i class=""></i>Situação</th>
                        </tr>
                        </thead>
                        <tbody class="justify-content-start">
                        <?php
                        foreach ($lista_ordem_servico as $item) :
                            ?>
                            <tr class="text-center">
                                <td><?= $item["nome_cliente_empresa"] ?></td>
                                <td><?= $item["modelo_veiculo"] ?></td>
                                <td><?= $item["placa_veiculo"] ?></td>
                                <td><?= $item["situacao_descricao"] ?></td>
                                <!-- <td>
                                <a class="btn btn-outline-light" href="formulario_os_alterar.php?id_os=<?=$item['id_os']?>"> <i class="fa-solid fa-circle-plus"></i></a>
                                </td> -->
                            </tr>
                        <?php
                        endforeach
                        ?>
                        </tbody>
                    </div>
                </table>
            </div>
        </div>
    </div>

    <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
            integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
            crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
            integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
            crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>

</div>
</body>
<script src="../assets/js/login.js"></script>
</html>
