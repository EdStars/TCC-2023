<?php
  session_start();
  if(!isset($_SESSION["usuario_logado"])){
    header("Location: ../index.php");
  }

//var_dump($_SESSION["usuario_logado"]);
//die();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

     <!-- Adicionando o arquivo de estilo do Bootstrap -->
   <!-- Adicionando o arquivo de estilo do Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/extras.js"></script>
    <script src="../assets/js/extras.js"></script>
     <!-- Titulo da Página -->
    <title>AutoMecânica</title> 

</head>
<body>   
<div class="inicio shadow-5-strong">
  <!-- Inicio da Barra de Navegação -->
  <?php include("templates/navbar_admin.php"); ?>
</div>
      
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
</body>
</html>