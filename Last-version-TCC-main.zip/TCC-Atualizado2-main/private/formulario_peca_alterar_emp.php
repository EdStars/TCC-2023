<?php
    date_default_timezone_set('America/Sao_Paulo');
    require("../database/funcoes.php");
    session_start();
    if(!isset($_SESSION["usuario_logado"])){
      header("Location: ../index.php");
    }
    $id_peca = $_GET["id_peca"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $pecaEmp = buscarPecaEmp($id_peca, $id_empresa);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Adicionando o arquivo de estilo do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/extras.js"></script>
     <!-- Titulo da Página -->
    <title>AutoMecânica</title> 

</head>
<body>   
 <div class="empresa">

<!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>

    <!-- Fim da Barra de Navegação -->
    <div id="inicio" class="container mt-2"></div>
    <div class="col-6 mx-auto">
      <div class="card shadow-lg bg-dark text-white">
      <a class="text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3" href="estoque_emp.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
        <div class="card-header">
          <h5>Alterar peça</h5>
          <small>Informe os seguintes dados da peça a ser alterada!</small>
        </div>
                    <!--  INICIO DO FORM   -->
                    <form class="form-group" action="../src/alterar_peca_emp.php" method="post">
                             <input type="hidden" value="<?=$pecaEmp["id_peca_emp"]?>" name="id_peca">
                        <div class="form-group px-5 mt-2">
                             <label>Nome da Peça:</label>
                             <input class="form-control form-item text-dark bg-white opacity-70" type="hidden"  id="id_nome_peca" name="nome_peca" value="<?=$pecaEmp["nome_peca"]?>">
                             <input class="form-control form-item text-dark bg-white opacity-70" type="text"  id="id_nome_peca" value="<?=$pecaEmp["nome_peca"]?>" disabled>
                        </div>
                        <div class="form-group px-5 mt-2">
                             <label>Código da Peça:</label>
                             <input class="form-control form-item text-dark bg-white opacity-70" type="hidden"  id="id_cod_peca" name="cod_peca" value="<?=$pecaEmp["cod_peca"]?>">
                             <input class="form-control form-item text-dark bg-white opacity-70" type="text"  id="id_cod_peca" value="<?=$pecaEmp["cod_peca"]?>" disabled>
                        </div>
                        <div class="form-group px-5 mt-2">
                             <label>Quantidade da Peça:</label>
                             <input  class="form-control form-item" type="number" id="id_quantidade" name="quantidade" value="<?=$pecaEmp["quantidade"]?>">
                        </div>
                        <div class="form-group px-5 mt-2">
                             <label>Data da Atualização:</label>
                             <input class="form-control form-item text-dark bg-white opacity-70"type="hidden"  id="id_data" name="data" value="<?=date('Y-m-d')?>">
                             <input class="form-control form-item text-dark bg-white opacity-70"type="text"  id="id_data"  value="<?=date('Y-m-d')?>" disabled>
                        </div>
                        <div class="form-group px-5 mt-2">
                             <label>Custo da peça:</label>
                             <input class="form-control form-item" data-mask='R$ #.##0,00' type="number" id="id_custo" name="custo" value="<?=$pecaEmp["custo_peca"]?>">
                        </div>
                        <div class="form-group px-5 mt-2">
                             <label>Lucro pretendido:</label>
                             <input class="form-control form-item" data-mask='0%' type="text" id="id_lucro" name="lucro" value="<?=$pecaEmp["lucro_peca"]?>">
                        </div>
                        <div class="card-footer form-item">
                          <div class="text-center mt-2">
                                <input class="form-icon-trailing text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3 mb-3" value="✎ Alterar" type="submit">
                         </div>
                       </div>
                    </form>
                    <!--   FIM DO FORM  -->
      </div>
  </div>
</div>
  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
  
  </div>
</body>
<script src="../assets/js/login.js"></script>
<html>



