<?php
require("../database/conecta_bd.php");

$chave = filter_input(INPUT_GET, 'chave', FILTER_DEFAULT);
if (!empty($chave)) {
    $sql = "SELECT id_tipo_usuario, id_usuario, id_referencia
            FROM Usuario
            WHERE chave_senha_recuperar = ?
            LIMIT 1";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $chave);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $result_usuario = mysqli_fetch_assoc($resultado);

    if (!empty($result_usuario)) {
        $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

        switch ($result_usuario["id_tipo_usuario"]) {
            case 1:
                if (isset($dados["nova_senha"])) {
                    $senha_md5 = md5($dados["nova_senha"]);
                    $sql = "UPDATE Administrador
                            SET senha_admin = ?
                            WHERE id_admin = ?
                            LIMIT 1";
                    $stmt = $conexao->prepare($sql);
                    $stmt->bind_param("si", $senha_md5, $result_usuario["id_referencia"]);

                    if ($stmt->execute()) {
                        $sql = "UPDATE Usuario
                                SET senha_usuario = ?, chave_senha_recuperar = null
                                WHERE id_usuario = ?
                                LIMIT 1";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bind_param("si", $senha_md5, $result_usuario["id_usuario"]);

                        if ($stmt->execute()) {
                            session_start();
                            $_SESSION["msg"] = "<p>Senha alterada com sucesso!</p>";
                            $_SESSION["tipo_msg"] = "alert-success";
                            header("Location: login.php");
                            exit();
                        } else {
                            echo "Erro na alteração! Tente novamente!";
                        }
                    } else {
                        echo "Erro na alteração! Tente novamente!";
                    }
                } else {
                    echo "Nova senha não foi enviada!";
                }
                break;

                case 2: // Empresa
                    if (isset($dados["nova_senha"])) {
                        $senha_md5 = md5($dados["nova_senha"]);
                
                        // Atualize a senha da empresa (ajuste a tabela e os campos conforme necessário)
                        $sql = "UPDATE Empresa
                                SET senha_empresa = ?
                                WHERE id_empresa = ?
                                LIMIT 1";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bind_param("si", $senha_md5, $result_usuario["id_referencia"]);
                
                        if ($stmt->execute()) {
                            // Atualize a senha do usuário
                            $sql = "UPDATE Usuario
                                    SET senha_usuario = ?, chave_senha_recuperar = null
                                    WHERE id_usuario = ?
                                    LIMIT 1";
                            $stmt = $conexao->prepare($sql);
                            $stmt->bind_param("si", $senha_md5, $result_usuario["id_usuario"]);
                
                            if ($stmt->execute()) {
                                session_start();
                                $_SESSION["msg"] = "<p>Senha alterada com sucesso!</p>";
                                $_SESSION["tipo_msg"] = "alert-success";
                                header("Location: login.php");
                                exit();
                            } else {
                                echo "Erro na alteração! Tente novamente!";
                            }
                        } else {
                            echo "Erro na alteração! Tente novamente!";
                        }
                    } else {
                        echo "Nova senha não foi enviada!";
                    }
                    break;                

                    case 3: // Cliente
                        if (isset($dados["nova_senha"])) {
                            $senha_md5 = md5($dados["nova_senha"]);
                    
                            // Atualize a senha do cliente (ajuste a tabela e os campos conforme necessário)
                            $sql = "UPDATE Cliente
                                    SET senha_cliente = ?
                                    WHERE id_cliente = ?
                                    LIMIT 1";
                            $stmt = $conexao->prepare($sql);
                            $stmt->bind_param("si", $senha_md5, $result_usuario["id_referencia"]);
                    
                            if ($stmt->execute()) {
                                // Atualize a senha do usuário
                                $sql = "UPDATE Usuario
                                        SET senha_usuario = ?, chave_senha_recuperar = null
                                        WHERE id_usuario = ?
                                        LIMIT 1";
                                $stmt = $conexao->prepare($sql);
                                $stmt->bind_param("si", $senha_md5, $result_usuario["id_usuario"]);
                    
                                if ($stmt->execute()) {
                                    session_start();
                                    $_SESSION["msg"] = "<p>Senha alterada com sucesso!</p>";
                                    $_SESSION["tipo_msg"] = "alert-success";
                                    header("Location: login.php");
                                    exit();
                                } else {
                                    echo "Erro na alteração! Tente novamente!";
                                }
                            } else {
                                echo "Erro na alteração! Tente novamente!";
                            }
                        } else {
                            echo "Nova senha não foi enviada!";
                        }
                        break;
                    
            default:
                echo "Tipo de usuário não reconhecido.";
        }
    } else {
        echo "Link Inválido! Solicite um novo link para atualizar a senha.";
    }
} else {
    echo "Chave de recuperação inválida!";
}
?>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Adicionando o arquivo de estilo do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/extras.js"></script>
     <!-- Titulo da Página -->
    <title>AutoMecânica</title> 

</head>
<body>   
 <div class="inicio shadow-5-strong">
  <!-- Inicio da Barra de Navegação -->
  <nav class="navbar navbar-expand-lg bgcimento navbar-dark bg-dark shadow-5-strong">
    <div class="container">
      <a class="navbar-brand ml-3 shadow-3-strong" href="../home.php"><img src="../assets/img/logo.png" widht="50" height="50"></a>
      <button class="navbar-toggler mr-4" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span><i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
             <div class="dropdown" id="DropdownHome">
              <a class="nav-link text-decoration-none shadow-3-strong btn btn-sm ml-1 mr-1" href="../private/login.php"><i class="fa-solid fa-house"></i> Entrar</a>
              <!--
             <div class="dropdown-menu bg-dark p-2">
              
             <form action="../src/valida_login.php" method="POST">
             <div class="form-group">
                        <label class="text-white" for="id_email">Email:</label>
                        <input class="form-control" type="email" id="id_email" placeholder="Digite seu Email" name="email">
                        
                     
                         <label class="text-white" for="id_senha">Senha:</label>
                          <div class="input-group">
                              <input class="form-control" type="password" id="id_senha" placeholder="Insira sua senha" name="senha" aria-describedby="button-addon2">      
                        </div>
             </form>
             <button class="btn-sm btn-primary btn-block mt-2 shadow-5-strong" type="button" id="id_btn_login" name="btn_login">Entrar <i class="fa-solid fa-right-to-bracket"></i></button> 
               </div>
              -->
            </div>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm nav-link ml-1 shadow-3-strong mr-1" href="../private/registro.php"><i class="fa-solid fa-car"></i> Cadastre-se</a>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm nav-link ml-1 shadow-3-strong mr-1" href="../public/contatnos.php"><i class="mx-1 fa-solid fa-phone"></i>Contate-nos</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>  
  <div class="container-fluid">
		<div class="row justify-content-center mt-3">
			<div class="col-md-5 col-lg-5">
				<div class="text-white mb-3 mt-2 bg-dark rounded-3 shadow-5-strong">
				   <div class="p-3 shadow-5-strong">
						<h5 class="text-center mb-4 p-1"><i class="mx-1 fa-solid fa-users"></i> Alterar Senha - <b>AutoMecânica</b> <i class="fas fa-users-gear"></i></h5>
              <!-- INICIO DO FORM-->     
        <form action="" method="POST">
        <br>
        <center>
        <div>
            <label for="nova_senha">Digite uma nova senha</label><br>
            <input class="form-control px-5" type="password" name="nova_senha" placeholder="Digite uma nova senha">
        </div>
        <br>
        <input class="btn btn-primary btn-sm mt-3" type="submit" name="atualizar_senha">

        <br><br>

        Lembrou a senha? <a class="btn btn-primary btn-sm" href="login.php">Clique aqui!</a>
    </form>
                </div>
		  </div>
          </center>
	    </div>
     </div>
  </div>
</div> 
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>

</body>
</html>