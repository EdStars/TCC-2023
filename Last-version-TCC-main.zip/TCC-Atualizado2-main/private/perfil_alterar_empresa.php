<?php
session_start();
if(!isset($_SESSION["usuario_logado"])){
  header("Location: ../home.php");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
     <!-- Titulo da Página -->
    <title>AutoMecanica</title> 

</head>
<body>   
 <div class="empresa"> 
<!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>

<div id="inicio"></div>
<div class="container">
    <div class="row">
     <a class="text-white text-decoration-none btn btn-lg shadow-3-lg p-3 bg-dark rounded-3" href="index_empresa.php"><i class="fas fa-circle-arrow-left"></i> Voltar (início)</a>
    <div class="col-8 mx-auto">
      <div class="card shadow-lg bg-dark text-white mt-3">
          <div class="card-header">
          </div>   <!--  INICIO DO FORM   -->

          <form class="form-group text-center" action="" method="post">
          <small>Os dados a seguir são do seu <b>Perfil</b>:</small>
              <div class="card-body text-white">
              <div class="form-item text-center mt-3">
                  <img src="https://via.placeholder.com/15x15" width="90" height="90" class="rounded-circle">
              </div>
               <div class="form-item mt-3 text-center">
                    <label for="nome">Nome:</label>
                    <input class="text-dark bg-white opacity-70" type="text" id="nome" disabled="disabled" name="nome" value="<?= $_SESSION["usuario_logado"]["nome_empresa"] ?>" required>
               </div>
              <div class="form-item mt-3 text-center">
                  <label for="email">E-mail:</label>
                  <input class="text-dark bg-white opacity-70" type="email" id="email" disabled="disabled" name="block" value="<?= $_SESSION["usuario_logado"]["email_empresa"] ?>" required>
              </div>
               <div class="form-item mt-3 text-center">
                   <label for="senha">Senha:</label>
                   <input class="text-dark bg-white opacity-70" type="password" disabled="disabled" id="senha" name="senha" required>
               </div>
               </div>
              <div class="card-footer">    
                <a href="#" class="text-decoration-none text-white text-center"><i class="fa-solid fa-pen-to-square"></i> Editar Perfil</a>            
              </div>
          </form>    <!--   FIM DO FORM  --> 

      </div>
  </div>
</div>



  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
  
  </div>
</body>
<script src="../assets/js/login.js"></script>
<html>