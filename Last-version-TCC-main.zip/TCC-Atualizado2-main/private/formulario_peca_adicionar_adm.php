<?php
session_start();
if(!isset($_SESSION["usuario_logado"])){
  header("Location: ../index.php");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
     <!-- Titulo da Página -->
    <title>AutoMecanica</title> 

</head>
<body>   
  <div class="inicio">
  <!-- Inicio da Barra de Navegação -->
  <!-- Código inserindo a barra de navegação--><?php include("templates/navbar_admin.php") ?>
    <div id="inicio" class="container mt-2"></div>
    <div class="col-6 mx-auto">
      <div class="card shadow-lg bg-dark text-white">
      <a class="text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3" href="estoque_adm.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
        <div class="card-header">
          <h5>Adicionar uma nova peça</h5>
          <small>Informe os seguintes dados da peça a ser adicionada!</small>
        </div>
        <!-- INICIO DO FORM -->
        <form class="form-group text-center" action="../src/adicionar_peca_adm.php" method="post">
          <div class="card-body">
            <div class="form-group form-item mt-2">
              <label>Nome da Peça:</label>
              <input type="text" id="id_nome_peca" placeholder="Digite o nome da peça" name="nome_peca">
            </div>
            <div class="form-group form-item mt-2">
              <label>Código da Peça:</label>
              <input type="text" id="id_cod_peca" placeholder="Digite o código da peça" name="cod_peca">
            </div>
          </div>
          <div class="card-footer form-item">
            <input type="submit" value="Adicionar" class="btn btn-outline-light">
          </div>
        </form>
        <!-- FIM DO FORM -->
      </div>
  </div>
</div>

  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
  
  </div>
</body>
<script src="../assets/js/login.js"></script>
<html>