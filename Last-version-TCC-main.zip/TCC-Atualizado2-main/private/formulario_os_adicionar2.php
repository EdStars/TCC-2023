<?php
    require("../database/funcoes.php");
    session_start();
    if(!isset($_SESSION["usuario_logado"])){
      header("Location: ../index.php");
    }
    $id_cliente_emp = $_POST["cliente"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $lista_clientes = ListarClientes($id_empresa);
    $lista_veiculos = ListarVeiculos($id_empresa, $id_cliente_emp);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

     <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
     <!-- Titulo da Página -->
    <title>AutoMecanica</title> 

</head>
<body>   
 <div class="empresa">

 <!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>
   
<div id="inicio" class="container mt-2"></div>
    <div class="col-6 mx-auto">
      <div class="card shadow-lg bg-dark text-white">
      <a class="text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3" href="listar_servico.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
        <div class="card-header">
          <h5>Nova Ordem de Serviço</h5>
          <small>Informe os seguintes dados da ordem de serviço!</small>
        </div>
        <!-- INICIO DO FORM -->
        <form class="form-group text-center" action="../src/adicionar_os.php" method="post">
          <div class="card-body">
          <div class="form-group px-5 mt-2">
              <label>Qual o nome do cliente?</label>
              <input type="hidden" name="cliente" value="<?=$id_cliente_emp?>">
              <select class="form-select form-item"  disabled>
                        <?php foreach ($lista_clientes as $cliente) : 
                            $estaSelecionado = $cliente["id_cliente_empresa"] == $id_cliente_emp;
                            $atributoSelected = $estaSelecionado ? "selected='selected'" : ""; 
                        ?>
                            <option value="<?=$cliente["id_cliente_empresa"]?>" <?=$atributoSelected?>>
                            <?=$cliente["nome_cliente_empresa"]?>
                            </option>
                        <?php endforeach ?>
                        </select>                    
              <label>Qual o veiculo do Cliente?</label>
              <select class="form-select form-item" name="veiculo" id="id_veiculo">
                <?php foreach ($lista_veiculos as $veiculo) : ?>
                <option value="<?=$veiculo['id_veiculo']?>" selected>
                <?=$veiculo["modelo_veiculo"]?>, <?=$veiculo["placa_veiculo"]?>
                </option>
                <?php endforeach ?>
                </select>
          </div>
          <div class="card-footer form-item">
            
          <div class="text-center mt-2">
                    <input class="form-icon-trailing text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3 mb-3" value="Solicitar" type="submit">
                </div>
          </div>
        </form>
        <!-- FIM DO FORM -->
      </div>
  </div>
</div>

  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
  
  </div>
</body>
<script src="../assets/js/login.js"></script>
<html>

<?php
                    $lista_notificacoes = [];
                    $id_cliente= $_SESSION["usuario_logado"]["id_cliente"];
                    $sql = "SELECT n.id_notificacao, n.id_empresa, n.id_cliente, e.nome_empresa 
                            FROM notificacao_requisito_servico n
                            INNER JOIN Empresa e
                            ON n.id_empresa = e.id_empresa
                            WHERE n.id_cliente = ?";
              
                    $conexao = obterConexao();
                    $stmt = $conexao->prepare($sql);
                    $stmt->bind_param("i", $id_cliente);
                    $stmt->execute();
                    $resultado = $stmt->get_result();
                    while ($notificacao = mysqli_fetch_assoc($resultado)) {
                      array_push($lista_notificacoes, $notificacao);
                    }
                    $stmt->close();
                    $conexao->close();
                    

                    
                    foreach ($lista_notificacoes as $item) :
                    ?>
                    <tr class="text-center"> 
                      <td>Empresa: <b><?= $item["nome_empresa"] ?></b></td>
                      <td>
                         <a class="btn btn-outline-light" href="../src/aceita.php?id_notificacao=<?=$item['id_notificacao']?>"> Sim</a>  
                       </td>
                       <td>
                          <a class="btn btn-outline-light" href="../src/rejeita.php?id_notificacao=<?=$item['id_notificacao']?>"> Não</a>  
                        </td>
                      </tr>  
                <?php
                endforeach
                ?>