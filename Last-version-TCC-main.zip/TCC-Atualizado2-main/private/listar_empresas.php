<?php
session_start();
if(!isset($_SESSION["usuario_logado"])){
    header("Location: ../index.php");
  }
require("../database/funcoes.php");
$lista_emp = ListarEmpresas();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
     <!-- Titulo da Página -->
    <title>AutoMecanica</title> 

</head>
<body>   
 <div class="usuario">
 <!-- Código inserindo a barra de navegação--><?php include("templates/navbarUser.php") ?>
     <div class="container">
     <div class="row bg-dark">
     <a class="text-white text-decoration-none btn btn-lg shadow-3-lg p-3" href="perfil_usuario.php"><i class="fas fa-circle-arrow-left"></i> Voltar (início)</a>
     <div class="table-responsive bg-dark border border-top">
     <table class="col-12 table table-hover table-dark">
            <thead class="thead-dark">
                              <tr class="text-center">
                                 <th scope="col"><i class="fa-solid fa-wrench"></i> Nome da Empresa</th>
                                 <th scope="col"><i class="fas fa-house-chimney-user"></i> Visitar Perfil</th>
                              </tr>
                         </thead>
                         <tbody>
                            <?php
                                foreach ($lista_emp as $item) :
                            ?>
                             <tr class="text-center"> 
                                <td><?= $item["nome_empresa"] ?></td>
                                <td>
                                <a class="btn btn-outline-light" href="perfil_visitar_empresa.php?id_empresa=<?=$item['id_empresa']?>"> <i class="fas fa-right-to-bracket"></i></a>  
                                </td>
                            </tr>  
                            <?php
                            endforeach
                            ?>
                                             
                           </tbody>
                       </table>
                     </div>
                </div>
             </div>
        </div>

  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>

 </div>
</body>
<script src="../assets/js/login.js"></script>
<html>