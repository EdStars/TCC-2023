<?php
require("../database/funcoes.php");
include("../utils/formatacoes.php");
include("../utils/mensagens.php");
session_start();
if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../index.php");
}
$id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
$lista_clientes = ListarClientes($id_empresa);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
    <!-- Titulo da Página -->
    <title>AutoMecanica</title>

</head>

<body>
<div class="empresa">
    <!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>
    <div class="container">
        <?php exibirMsg() ?>
        <div class="row bg-dark">
            <a class="text-white text-decoration-none btn btn-lg shadow-3-lg p-3" href="index_empresa.php"><i
                    class="fas fa-circle-arrow-left"></i> Voltar</a>
            <div class="table-responsive bg-dark border border-top">
                <table class="col-12 table table-hover table-dark">
                    <thead class="thead-dark">
                    <tr class="text-center text-white">
                        <th scope="col"><a class="text-decoration-none text-white btn shadow-3-lg"href="formulario_adicionar_cliente.php"> <i class="fa-solid fa-circle-plus"></i> Adicionar Cliente</a></th>
                        <th scope="col"><i class="far fa-address-book"></i> <b>Nome do Cliente</b></th>
                        <th scope="col"><i class="far fa-address-book"></i> <b>Telefone do Cliente</b></th>
                        <th scope="col"><i class="far fa-address-book"></i> <b>CPF do Cliente</b></th>
                        <th scope="col"><i class="far fa-address-book"></i> <b>Email do Cliente</b></th>
                        <th scope="col"><i class="far fa-address-book"></i> <b>Veiculos do Cliente</b></th>
                        <th scope="col"><i class="fas fa-circle-xmark"></i> <b>Remover Cliente</b></th>
                        <th scope="col"><i class="fa-solid fa-circle-plus"></i> <b>Adicionar Veiculo</b></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $index = 0; // Variável para criar IDs únicos para os colapsos
                    foreach ($lista_clientes as $item) :
                        $id_cliente_emp = $item["id_cliente_empresa"];
                        $index++;
                        $collapseId = "collapseExample" . $index; // ID único para o colapso
                        ?>
                        <tr class="text-center">
                            <td><i class="opacity-70 fas fa-2x fa-user-large"></i></td>
                            <td class="opacity-70"><?= $item["nome_cliente_empresa"] ?></td>
                            <td class="opacity-70"><?= $item["telefone_cliente_empresa"] ?></td>
                            <td class="opacity-70"><?= $item["cpf_cliente_empresa"] ?></td>
                            <td class="opacity-70"><?= $item["email_cliente_empresa"] ?></td>
                            <td>
                                <div>
                                    <p class="d-inline-flex gap-1" style="width: 100% !important">
                                        <a class="btn btn-small btn-dark text-white shadow-3-strong" data-bs-toggle="collapse"
                                           href="#<?= $collapseId ?>" role="button" aria-expanded="false"
                                           aria-controls="<?= $collapseId ?>" style="width: 100%">
                                            <?= $item["nome_cliente_empresa"] ?>
                                        </a>
                                    </p>
                                    <div class="collapse bg-dark shadow-3-strong" id="<?= $collapseId ?>">
                                        <div class="card card-body bg-dark text-white shadow-3-strong p-3 mb-3 border-1 border">
                                            <div class="text-center">
                                                <?php
                                                $lista_veiculos = ListarVeiculos($id_empresa, $id_cliente_emp);
                                                foreach ($lista_veiculos as $veiculo) :
                                                    ?>
                                                    <table class="shadow-3-strong border border-white rounded mt-2">
                                                        <thead>
                                                        <th><b>Modelo</b></th>
                                                        <th><b>Placa </b></th>
                                                        </thead>
                                                        <tbody>
                                                        <th class="opacity-70"><?= $veiculo["modelo_veiculo"] ?></th>
                                                        <th class="opacity-70"><?= $veiculo["placa_veiculo"] ?></th>
                                                        </tbody>
                                                        <tfoot>
                                                        <th><a class="btn btn-small shadow-3-strong btn-outline-dark text-white mb-1" href="formulario_alterar_veiculo.php?id_veiculo=<?= $veiculo['id_veiculo'] ?>"> Alterar</a></th>
                                                        <th>
                                                            <form action="../src/remover_veiculo.php" method="post">
                                                                <input type="hidden" name="modelo" value="<?= $veiculo["modelo_veiculo"] ?>">
                                                                <input type="hidden" name="id" value="<?= $veiculo["id_veiculo"] ?>">
                                                                <input type="hidden" name="placa" value="<?= $veiculo["placa_veiculo"] ?>">
                                                                <p><input type="submit" class="btn btn-small shadow-3-strong btn-outline-dark text-white mt-3" value="Remover"></p>
                                                            </form>
                                                        </th>
                                                        </tfoot>
                                                        
                                                    </table>
                                                <?php endforeach ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <form action="../src/remover_cliente.php" method="POST">
                                    <input type="hidden" name="nome" value="<?= $item["nome_cliente_empresa"] ?>">
                                    <input type="hidden" name="id" value="<?= $id_cliente_emp ?>">
                                    <input type="submit" value="Remover" class="btn btn-outline-light">
                                </form>
                            </td>
                            <td> <a class="btn btn-small shadow-3-strong btn-outline-dark text-white mb-3" href="formulario_adicionar_veiculo.php?id_cliente_emp=<?= $id_cliente_emp ?>">Adicionar</a>
                        </tr>
                    <?php
                    endforeach
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

 <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
</body>
<script src="../assets/js/login.js"></script>
</html>
