<?php
 include("../database/conecta_bd.php");
 require("../database/funcoes.php");
 session_start();
 if(!isset($_SESSION["usuario_logado"])){
  header("Location: ../index.php");
 }
 $id_empresa = $_GET["id_empresa"];
 $dadosEmpresa = MostrarDadosEmpresa($id_empresa);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

      <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
    <title>AutoMecanica</title> 

</head>
<body>   
 <div class="usuario"> 
<!-- Código inserindo a barra de navegação--><?php include("templates/navbarUser.php") ?>


<div id="inicio"></div>
 <div class="container">
    <div class="row">
     <a class="text-white text-decoration-none btn btn-lg shadow-3-lg p-3 bg-dark" href="perfil_usuario.php"><i class="fas fa-circle-arrow-left"></i> Voltar (início)</a>
    <div class="col-8 mx-auto p-3">
      <div class="card shadow-lg bg-dark text-white">
          <div class="card-header">
          <?php
                foreach ($dadosEmpresa as $item) :
          ?>
            <h5 class="text-center">Perfil da Empresa:</h5>
            <h4 class="text-center"><b><?= $item["nome_empresa"] ?></b></h4>
          </div>   <!--  INICIO DO FORM   -->
          <form class="form-group text-center" action="" method="post">
          <small>Sobre a empresa <?= $item["nome_empresa"] ?></small>
              <div class="card-body text-white">
              <div class="form-item text-center mt-3">
                  <img src="https://via.placeholder.com/15x15" width="90" height="90" class="rounded-circle">
              </div>
               <div class="form-item mt-3 text-center">
                    <label for="nome">Endereço</label>
                    <p><?= $item["endereco_empresa"] ?></p>
                    
               </div>
              <div class="form-item mt-3 text-center">
                  <label for="email">E-mail:</label>
                  <p><?= $item["email_empresa"] ?></p>
                  
              </div>
               <div class="form-item mt-3 text-center">
                   <label for="senha">Telefone:</label>
                   <p><?= $item["telefone_empresa"] ?></p>
                   
               </div>
               <?php  endforeach ?>
               </div>
              <div class="card-footer">    
                <a href="#" class="text-decoration-none text-white text-center">Avaliação: </a>            
              </div>
          </form>    <!--   FIM DO FORM  --> 
          </div>
      </div>
  </div>
</div>


<!-- Código inserindo os scrpits JS--><?php include("templates/scripts.php") ?>
  
  </div>
</body>
<script src="../assets/js/login.js"></script>
<html>