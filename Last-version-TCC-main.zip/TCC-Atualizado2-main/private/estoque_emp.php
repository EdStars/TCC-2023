<?php
require("../database/funcoes.php");
include("../utils/formatacoes.php");  
include("../utils/mensagens.php");
session_start();
if(!isset($_SESSION["usuario_logado"])){
    header("Location: ../index.php");
}
$id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
$estoqueEmp = MostrarEstoqueEmp($id_empresa);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

     <!-- Código inserindo os links e scripts do head--><?php include("templates/linkshead.php") ?>
     <!-- Titulo da Página -->
    <title>AutoMecanica</title> 

</head>
<body>   
 <div class="empresa">
<!-- Código inserindo a barra de navegação--><?php include("templates/navbarEmpresa.php") ?>
    <?php
            exibirMsg();
    ?>
     <div class="container">
     <div class="row bg-dark">
     <a class="text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3" href="index_empresa.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
     <div class="table-responsive bg-dark border border-top">
     <table class="col-12 table table-hover table-dark">
            <thead class="thead-dark">
                              <tr class="text-center">
                                 <th  class="p-1" scope="col"><a class="text-decoration-none text-white btn shadow-3-lg" href="listar_pecas.php" ><i class="fa-solid fa-circle-plus"></i> Adicionar peça</a></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-wrench"></i> <b>Nome/Peça</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-wrench"></i> <b>Código da Peça</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-briefcase"></i> <b>Quantidade</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-calendar"></i> <b>Data de Atualização</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-hand-holding-dollar"></i> <b>Custo Peça (Unidade)</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-hand-holding-dollar"></i> <b>Custo em Estoque (Total)</b></th>
                                 <th  class="p-1" scope="col"><i class="fas fa-coins"></i> <b>Lucro porcentual</b></th>
                                 <th  class="p-1" scope="col"><i class="fas fa-coins"></i> <b>Lucro por peça</b></th>
                                 <th  class="p-1" scope="col"><i class="fa-solid fa-pen-to-square"></i> <b>Alterar Informações</b></th>
                                 <th  class="p-1" scope="col"><i class="fas fa-circle-xmark"></i> <b>Remover Peça</b></th>
                              </tr>
                         </thead>
                         <tbody>
                            <?php
                                foreach ($estoqueEmp as $item) :
                            ?>
                             <tr class="text-center"> 
                                <td></td>
                                <td><?= $item["nome_peca"] ?></td>
                                <td><?= $item["cod_peca"] ?></td>
                                <td><?= $item["quantidade"] ?></td>
                                <td><?= formata_data_pagina($item["data_atualizacao"]) ?></td>
                                <td>R$<?= $item["custo_peca"]?></td>
                                <td>R$<?= $item["custo_estoque"]?></td>
                                <td><?= $item["lucro_peca"]?>%</td>
                                <td>R$<?= $item["lucro_peca_final"]?></td>
                                <td>
                                <a class="btn btn-outline-light" href="formulario_peca_alterar_emp.php?id_peca=<?=$item['id_peca_emp']?>"> <i class="fa-solid fa-pencil"></i></a>  
                                </td>
                                <td>
                                    <form action="../src/remover_peca_emp.php" method="POST">
                                        <input type="hidden" name="nome" value="<?= $item["nome_peca"]?>">
                                        <input type="hidden" name="id" value="<?= $item["id_peca_emp"]?>">
                                        <input type="submit" value="Remover" class="btn btn-outline-light">
                                    </form>
                                </td>
                            </tr>  
                            <?php
                            endforeach
                            ?>
                                             
                           </tbody>
                       </table>
                     </div>
                </div>
             </div>
        </div> 
      </div>

  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>

 </div>
</body>
<script src="../assets/js/login.js"></script>
<html>