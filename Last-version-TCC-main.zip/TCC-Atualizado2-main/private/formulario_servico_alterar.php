<?php
require("../database/funcoes.php");
require("../utils/mensagens.php");
session_start();
if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../index.php");
}
$id_servico = $_GET["id_servico"];
$id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
$servico = buscarServico($id_servico, $id_empresa);
$id_cliente_emp = $servico["id_cliente_empresa"];
$id_veiculo = $servico["id_veiculo"];
$lista_clientes = ListarClientes($id_empresa);
$lista_veiculos = ListarVeiculos($id_empresa, $id_cliente_emp);
$lista_pecas = MostrarEstoqueEmp($id_empresa);
$lista_pecas_utilizadas = ListarPecaUtilizadas($id_empresa, $id_servico);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Código inserindo os links e scripts do head -->
    <?php include("templates/linkshead.php"); ?>

    <!-- Titulo da Página -->
    <title>AutoMecanica</title>
</head>

<body>
    <div class="empresa">
        <!-- Código inserindo a barra de navegação -->
        <?php include("templates/navbarEmpresa.php"); ?>
        <!-- Fim da Barra de Navegação -->
        <?php exibirMsg(); ?>
        <div id="inicio" class="container">
            <div class="row">
            <a class="text-white text-decoration-none shadow-3-lg p-3 btn btn-lg shadow-lg bg-dark text-white" href="listar_servico.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
                <div class="col-md-6">
                    <div class="card shadow-3-strong bg-dark text-white mt-2">
                        <div class="card-header">
                            <h5>Alterar Serviço</h5>
                            <small>Informe os seguintes dados da ordem de serviço a ser alterada!</small>
                        </div>
                        <!--  INICIO DO FORM   -->
                        <div class="card-body">
                            <form class="form-group" action="../src/alterar_servico.php" method="post">
                                <input type="hidden" value="<?= $id_servico ?>" name="id_servico">
                                <div class="form-group px-5 mt-2">
                                    <label>◉ Qual o nome do cliente?</label>
                                    <input type="hidden" name="cliente" value="<?= $id_cliente_emp ?>">
                                    <select class="form-select form-item" disabled>
                                        <?php foreach ($lista_clientes as $cliente) :
                                            $estaSelecionado = $cliente["id_cliente_empresa"] == $id_cliente_emp;
                                            $atributoSelected = $estaSelecionado ? "selected='selected'" : "";
                                        ?>
                                            <option value="<?= $cliente["id_cliente_empresa"] ?>" <?= $atributoSelected ?>>
                                                <?= $cliente["nome_cliente_empresa"] ?>
                                            </option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group px-5 mt-2">
                                    <label>◉ Qual o Veiculo do cliente?</label>
                                    <input type="hidden" name="veiculo" value="<?= $id_veiculo ?>">
                                    <select class="form-select form-item" disabled>
                                        <?php foreach ($lista_veiculos as $veiculo) : ?>
                                            <option><?= $veiculo["modelo_veiculo"] ?>, <?= $veiculo["placa_veiculo"] ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group px-5 mt-2">
                                    <label>◉ Qual o problema relatado pelo cliente? </label>
                                    <input class="form-control form-item" type="text" id="id_descricao_problema_cliente" name="descricao_problema_cliente"
                                        value="<?= $servico["descricao_problema_cliente"] ?>">
                                </div>
                                <div class="form-group px-5 mt-2">
                                    <label>◉ Quais foram as alterações feitas até agora? </label>
                                    <input class="form-control form-item" type="text" id="id_modificacoes" name="modificacoes" value="<?= $servico["modificacoes_servico"] ?>">
                                </div>
                                <div class="text-center">
                                    <input class="form-icon-trailing text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3 mb-3"
                                        value="✎ Alterar" type="submit">
                                </div>
                            </form>
                        </div>
                        <!--   FIM DO FORM  -->
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card shadow-3-strong bg-dark text-white mt-2">
                        <div class="card-header">
                            <h5>Adicionar peça utilizada</h5>
                            <small> Informe as peças que foram utilizadas no serviço </small>
                        </div>
                        <!--  INICIO DO FORM   -->
                        <div class="card-body">
                            <form method="POST" action="../src/adicionar_peca_utilizada.php">
                                <div class="form-group px-5 mt-2">
                                    <input type="hidden" value="<?= $id_servico ?>" name="id_servico">
                                    <label>◉ Quais peças foram usadas?</label>
                                    <select class="form-select form-item" name="peca">
                                        <?php foreach ($lista_pecas as $peca) : ?>
                                            <option value="<?= $peca["id_peca_emp"] ?>"><?= $peca["nome_peca"] ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group px-5 mt-2">
                                    <label> ◉ Quantas peças foram utilizadas? </label>
                                    <input class="form-control form-item" type="number" name="quantidade" required>
                                </div>
                                <div class="text-center">
                                    <input class="form-icon-trailing text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3 mb-3" value="+ Adicionar" type="submit" name="adicionar_peca">
                                </div>
                            </form>
                        </div>
                        <!--   FIM DO FORM  -->
                        <div class="card-header">
                            <h5> Peças Utilizadas </h5>
                        </div>
                        <table class="col-12 table table-hover table-dark" id="tabela_estoque">
                            <div class="d-flex">
                                <thead>
                                    <tr class="text-center">
                                        <th scope="col"><i class="fa-solid fa-wrench"></i> Nome da Peça</th>
                                        <th scope="col"><i class="fa-solid fa-wrench"></i> Código da Peça</th>
                                        <th scope="col"><i class=""></i>Quantidade</th>
                                        <th> Remover</th>
                                    </tr>
                                </thead>
                                <tbody class="justify-content-start">
                                    <?php
                                    foreach ($lista_pecas_utilizadas as $item) :
                                    ?>
                                        <tr class="text-center">
                                            <td><?= $item["nome_peca"] ?></td>
                                            <td><?= $item["cod_peca"] ?></td>
                                            <td><?= $item["quantidade_utilizada"] ?></td>
                                            <td>
                                                <form action="../src/remover_peca_utilizada.php" method="POST">
                                                    <input type="hidden" value="<?= $id_servico ?>" name="id_servico">
                                                    <input type="hidden" name="nome" value="<?= $item["nome_peca"]?>">
                                                    <input type="hidden" name="id" value="<?= $item["id_peca_utilizada"]?>">
                                                    <input type="submit" value="Remover" class="btn btn-outline-light">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php
                                    endforeach
                                    ?>
                                </tbody>
                            </div>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>
</body>
<script src="../assets/js/login.js"></script>
</html>
