<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Container wrapper -->
  <div class="container">
    <!-- Navbar brand -->
    <a class="navbar-brand ml-3 shadow-3-strong" href="perfil_usuario.php"><img src="../assets/img/logo.png" widht="50" height="50"></a>
       
    <!-- Toggle button -->
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarButtonsExample"
      aria-controls="navbarButtonsExample"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbarButtonsExample">
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
              <a class="nav-link btn shadow-3-lg" href="../private/listar_empresas.php"><i class="fas fa-address-card"></i> Empresas</a>
        </li>
      </ul>
      <!-- Left links -->

      <div class="d-flex align-items-center">
      <ul class="navbar-nav ml-auto">
           
            <li class="nav-item dropdown">
              <a class="nav-link btn shadow-3-lg" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-solid fa-inbox"></i> Notificações
              </a>
              <div class="dropdown-menu mr-1 ml-3 p-5 bg-dark" aria-labelledby="navbarDropdownMenuLink">
            </thead>
            <tbody>
                <?php    
                $lista_notificacoes = [];
                $id_cliente = $_SESSION["usuario_logado"]["id_cliente"];
                $sql = "SELECT n.id_notificacao, n.id_empresa, n.id_cliente, e.nome_empresa, v.modelo_veiculo, v.placa_veiculo 
                        FROM notificacao_requisito_servico n
                        INNER JOIN Empresa e ON n.id_empresa = e.id_empresa
                        INNER JOIN Veiculos v ON n.id_veiculo = v.id_veiculo
                        WHERE n.id_cliente = ?";
                  
                $conexao = obterConexao();
                $stmt = $conexao->prepare($sql);
                $stmt->bind_param("i", $id_cliente);
                $stmt->execute();
                $resultado = $stmt->get_result();
                while ($notificacao = mysqli_fetch_assoc($resultado)) {
                    array_push($lista_notificacoes, $notificacao);
                }
                $stmt->close();
                $conexao->close();
                ?>

                <?php
                if (!empty($lista_notificacoes)) {
                ?>
                <table class="col-12 table table-hover table-dark">
                    <thead class="thead-dark">
                        <tr class="text-center">
                            <th scope="col"><i class="fas fa-house-chimney-user"></i> - Empresa:</th>
                            <th scope="col"><i class="fas fa-house-chimney-user"></i> - Veiculo:</th>
                            <th scope="col" colspan="2"><i class="fas fa-house-chimney-user"></i> - Você requisitou este serviço?</th>
                        </tr>
                    </thead>
                    <?php
                    foreach ($lista_notificacoes as $item) {
                    ?>
                        <tr class="text-center"> 
                            <td> <b><?= $item["nome_empresa"] ?></b></td>
                            <td> <b><?= $item["modelo_veiculo"] ?>, <?= $item["placa_veiculo"]?></b></td>
                            <td>
                                <a class="btn btn-outline-light" href="../src/aceita.php?id_notificacao=<?= $item['id_notificacao'] ?>"> Sim</a>  
                            </td>
                            <td>
                                <a class="btn btn-outline-light" href="../src/rejeita.php?id_notificacao=<?= $item['id_notificacao'] ?>"> Não</a>  
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </table>
                <?php
                } else {
                    echo "<p> Não há Notificações! </p>";
                }
                ?>

              </div>
            </li>
           <li class="nav-item">
              <a class="nav-link btn text-decoration-none shadow-3-lg" href="perfil_alterar_usuario.php"><i class="fas fa-circle-user"></i> Perfil</a>
           </li>
           <li class="nav-item">
              <a class="nav-link btn text-decoration-none shadow-3-lg" href="../src/logout.php"><i class="fa-solid fa-door-open"></i> Sair</a>
           </li>
            
                
    
          </ul>
      </div>
    </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav>
<!-- Navbar -->