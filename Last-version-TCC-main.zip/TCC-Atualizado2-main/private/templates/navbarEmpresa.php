<!-- Navbar -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Container wrapper -->
  <div class="container">
    <!-- Navbar brand -->
    <a class="navbar-brand ml-3 shadow-3-strong" href="index_empresa.php"><img src="../assets/img/logo.png" widht="50" height="50"></a>
       
    <!-- Toggle button -->
    <button class="navbar-toggler mr-4" type="button" data-toggle="collapse" data-target="#navbar"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span><i class="fas fa-bars"></i>
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbar">
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         <!--  <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="../private/listar_veiculos.php"><i class="fas fa-car-side"></i> Veículos</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="../private/listar_servico.php"></i><i class="fas fa-bars-progress"></i> Serviços</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-decoration-none ml-3 btn btn-sm" href="estoque_emp.php"> <i class="fa-solid fa-boxes-stacked"></i> Estoque</a>
            </li>
            <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="../private/listar_clientes.php"><i class="fas fa-user-group"></i> Clientes</a>
            </li>
      </ul>
      <!-- Left links -->

      <div class="d-flex align-items-center">
      <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
              <a class="nav-link ml-3 btn btn-sm" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-bell "></i> Notificações
              </a>
              <div class="dropdown-menu mr-1 ml-3" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item text-muted" href="#">Sem notificações</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="perfil_alterar_empresa.php""><i class="fas fa-circle-user"></i> Perfil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="../src/logout.php"><i class="fa-solid fa-door-open"></i> Sair</a>
            </li>
          </ul>
      </div>
    </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav>
<!-- Navbar -->