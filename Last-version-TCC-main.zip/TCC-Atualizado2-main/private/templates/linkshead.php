<!-- Adicionando o arquivo de estilo do Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://jsuites.net/v4/jsuites.js"></script>