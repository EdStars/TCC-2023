
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Container wrapper -->
  <div class="container">
    <!-- Navbar brand -->
    <a class="navbar-brand ml-3 shadow-3-strong" href="../private/perfil_admin.php"><img src="../assets/img/logo.png" widht="50" height="50"></a><p class="text-success">Admin</p>
      <button class="navbar-toggler mr-4" type="button" data-toggle="collapse" data-target="#navbar"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span><i class="fas fa-bars"></i>
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbar">
      <!-- Left links -->
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
          <a class="nav-link ml-3 btn btn-sm" href="#"></i>Serviços</a>
      </li>
      <li class="nav-item">
          <a class="nav-link ml-3 btn btn-sm text-decoration-none" href="estoque_adm.php">Estoque</a>
      </li>
      <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="#">Clientes</a>
      </li>
    </ul>
      <!-- Left links -->

      <div class="d-flex align-items-center">
      <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link ml-3 btn btn-sm" href="../src/logout.php"><i class="fa-solid fa-door-open"></i> Sair</a>
            </li>
          </ul>
      </div>
    </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav>
<!-- Navbar -->