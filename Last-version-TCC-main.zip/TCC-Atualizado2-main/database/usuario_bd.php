<?php
require_once("conecta_bd.php");
if(!isset($_SESSION["usuario_logado"])){
  header("Location: ../index.php");
}

function Logout(){
  unset($_SESSION["usuario_logado"]);
  header("Location: ../index.php");
  die();
};


function buscarUsuarioAdmin($email, $senha) {
    $sql = "SELECT email_admin FROM Administrador WHERE email_admin = ?"; 
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $usuario = mysqli_fetch_assoc($resultado);
    if ($usuario == null) {
      $msg = "Email incorreto!"; 
    } else {
      $senha_md5 = md5($senha);
      $sql =  "SELECT id_admin, nome_admin, id_tipo_usuario FROM Administrador
              WHERE email_admin = ? AND senha_admin = ?";  
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("ss", $email, $senha_md5);
      $stmt->execute();
      $resultado = $stmt->get_result();
      $usuario = mysqli_fetch_assoc($resultado);
      if ($usuario == null) {
        $msg = "Senha incorreta!";  
      } else {
        $msg = null;
      }
    }
    $stmt->close();
    $conexao->close();
    return [$usuario, $msg];
};

function buscarUsuarioCliente($email, $senha) {
  $sql = "SELECT email_cliente FROM Cliente WHERE email_cliente = ?"; 
  $conexao = obterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $resultado = $stmt->get_result();
  $usuario = mysqli_fetch_assoc($resultado);
  if ($usuario == null) {
    $msg = "Email incorreto!"; 
  } else {
    $senha_md5 = md5($senha);
    $sql =  "SELECT id_cliente, nome_cliente, telefone_cliente, email_cliente, cpf_cliente, imagem_cliente, id_tipo_usuario FROM Cliente
            WHERE email_cliente = ? AND senha_cliente = ?";  
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $email, $senha_md5);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $usuario = mysqli_fetch_assoc($resultado);
    if ($usuario == null) {
      $msg = "Senha incorreta!";  
    } else {
      $msg = null;
    }
  }
  $stmt->close();
  $conexao->close();
  return [$usuario, $msg];
};

function buscarUsuarioEmpresa($email, $senha) {
  $sql = "SELECT email_empresa FROM Empresa WHERE email_empresa = ?"; 
  $conexao = obterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $resultado = $stmt->get_result();
  $usuario = mysqli_fetch_assoc($resultado);
  if ($usuario == null) {
    $msg = "Email incorreto!"; 
  } else {
    $senha_md5 = md5($senha);
    $sql =  "SELECT id_empresa, nome_empresa, endereco_empresa, telefone_empresa, email_empresa, cnpj_empresa, id_tipo_usuario FROM Empresa
            WHERE email_empresa = ? AND senha_empresa = ?";  
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $email, $senha_md5);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $usuario = mysqli_fetch_assoc($resultado);
    if ($usuario == null) {
      $msg = "Senha incorreta!";  
    } else {
      $msg = null;
    }
  }
  $stmt->close();
  $conexao->close();
  return [$usuario, $msg];
};

function CriarUsuario($nome, $id_referencia, $email, $senha, $id_tipo_usuario){
  $senha_md5 = md5($senha);
  $sql = "INSERT INTO Usuario(nome_usuario, id_referencia ,email_usuario ,senha_usuario ,id_tipo_usuario)
          VALUES (?, ?, ?, ?, ?)";
  $conexao = ObterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("sissi", $nome ,$id_referencia,$email, $senha_md5, $id_tipo_usuario);
  $stmt->execute();
  if ($stmt->affected_rows > 0) {
    $_SESSION["msg"] = "Sua conta foi criada com sucesso!";
    $_SESSION["tipo_msg"] = "alert-success";
  } else {
    $_SESSION["msg"] = "Não foi possivel criar sua conta! Erro:" . mysqli_error($conexao);
    $_SESSION["tipo_msg"] = "alert-danger";
  }
  $stmt->close();
  $conexao->close();
};

function CriarCliente($nome, $cpf, $telefone, $email, $senha, $imagem, $id_tipo_usuario){
  $senha_md5 = md5($senha);
  $sql = "INSERT INTO Cliente(nome_cliente, cpf_cliente, telefone_cliente, email_cliente, senha_cliente, imagem_cliente, id_tipo_usuario)
          VALUES (?, ?, ?, ?, ?, ?, ?)";
  $conexao = ObterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("ssssssi", $nome, $cpf, $telefone, $email, $senha_md5, $imagem, $id_tipo_usuario);
  $stmt->execute();
  $stmt->close();
  $conexao->close();
};

function CriarEmpresa($nome, $cnpj, $endereco, $telefone, $email, $senha, $imagem, $id_tipo_usuario){
  $senha_md5 = md5($senha);
  $sql = "INSERT INTO Empresa(nome_empresa, cnpj_empresa, endereco_empresa, telefone_empresa, email_empresa, senha_empresa, imagem_empresa, id_tipo_usuario)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  $conexao = ObterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("sssssssi", $nome, $cnpj, $endereco, $telefone, $email, $senha_md5, $imagem, $id_tipo_usuario);
  $stmt->execute();
  $stmt->close();
  $conexao->close();
};

function buscarUsuario($email, $senha) {
  $sql = "SELECT email_usuario FROM Usuario WHERE email_usuario = ?"; 
  $conexao = obterConexao();
  $stmt = $conexao->prepare($sql);
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $resultado = $stmt->get_result();
  $usuario = mysqli_fetch_assoc($resultado);
  if ($usuario == null) {
    $msg = "Email incorreto!"; 
  } else {
    $senha_md5 = md5($senha);
    $sql =  "SELECT * FROM Usuario
            WHERE email_usuario = ? AND senha_usuario = ?";  
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $email, $senha_md5);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $usuario = mysqli_fetch_assoc($resultado);
    if ($usuario == null) {
      $msg = "Senha incorreta!";  
    } else {
      $msg = null;
    }
  }
  $stmt->close();
  $conexao->close();
  return [$usuario, $msg];
};
?>