<?php
    //if (!isset($_SESSION)) {
      //session_start();
    //}

    require_once("conecta_bd.php");

    function MostrarEstoqueAdm(){
      $estoqueAdm = [];
      $sql = "SELECT * FROM Estoque_Admin";  
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->execute();
      $resultado = $stmt->get_result();
      while ($pecas = mysqli_fetch_assoc($resultado)) {
        array_push($estoqueAdm, $pecas);
      }
      $stmt->close();
      $conexao->close();
      return $estoqueAdm;
    }

    function MostrarEstoqueEmp($id_empresa){
        $estoqueEmp = [];
        $sql = "SELECT id_peca_emp, nome_peca, cod_peca, quantidade, data_atualizacao, custo_peca, custo_estoque, lucro_peca, lucro_peca_final FROM Estoque_Empresa WHERE id_empresa = ?" ;  
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id_empresa);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($pecas = mysqli_fetch_assoc($resultado)) {
          array_push($estoqueEmp, $pecas);
        }
        $stmt->close();
        $conexao->close();
        return $estoqueEmp;
    }

    function removerPecaEmp($id_peca, $id_empresa, $nome) {
        $sql = "DELETE FROM Estoque_Empresa 
                WHERE id_peca_emp = ? AND id_empresa = ?" ;
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id_peca, $id_empresa);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
          $_SESSION["msg"] = "A peça {$nome} foi removida!";
          $_SESSION["tipo_msg"] = "alert-danger";
        } else {
          $_SESSION["msg"] = "A peça {$nome} não foi removida! Erro:" . mysqli_error($conexao);
          $_SESSION["tipo_msg"] = "alert-danger";
        }
        $stmt->close();
        $conexao->close();
    }

    function removerPecaAdm($id_peca, $nome) {
      $sql = "DELETE FROM Estoque_Admin 
              WHERE id_peca_admin = ?" ;
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("i", $id_peca);
      $stmt->execute();
      if ($stmt->affected_rows > 0) {
        $_SESSION["msg"] = "A peça {$nome} foi removida!";
        $_SESSION["tipo_msg"] = "alert-danger";
      } else {
        $_SESSION["msg"] = "A peça {$nome} não foi removida! Erro:" . mysqli_error($conexao);
        $_SESSION["tipo_msg"] = "alert-danger";
      }
      $stmt->close();
      $conexao->close();
  }

    function InserirPecaEmp($nome, $cod, $quantidade, $data, $custo, $custof, $lucro, $lucrof, $id_empresa){
      $sql = "INSERT INTO Estoque_Empresa(nome_peca, cod_peca, quantidade, data_atualizacao, custo_peca, custo_estoque, lucro_peca, lucro_peca_final, id_empresa) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("ssisiiisi", $nome, $cod, $quantidade, $data, $custo, $custof, $lucro, $lucrof, $id_empresa);
      $stmt->execute();
      if ($stmt->affected_rows > 0) {
        $_SESSION["msg"] = "A peça {$nome} foi adicionado!";
        $_SESSION["tipo_msg"] = "alert-success";
      } else {
        $_SESSION["msg"] = "A peça {$nome} não foi adicionado! Erro:" . mysqli_error($conexao);
        $_SESSION["tipo_msg"] = "alert-danger";
      }
      $stmt->close();
      $conexao->close(); 
    }

    function InserirPecaAdm($nome, $cod){
      $sql = "INSERT INTO Estoque_Admin (nome_peca, cod_peca) 
              VALUES (?, ?)";
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("ss", $nome, $cod);
      $stmt->execute();
      if ($stmt->affected_rows > 0) {
        $_SESSION["msg"] = "A peça {$nome} foi adicionado!";
        $_SESSION["tipo_msg"] = "alert-success";
      } else {
        $_SESSION["msg"] = "A peça {$nome} não foi adicionado! Erro:" . mysqli_error($conexao);
        $_SESSION["tipo_msg"] = "alert-danger";
      }
      $stmt->close();
      $conexao->close(); 
    }

    Function AlterarPecaAdm($id_peca, $nome, $cod){
      $sql = "UPDATE Estoque_Admin 
              SET nome_peca = ?, cod_peca = ?
              WHERE id_peca_admin = ?";            
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("ssi", $nome, $cod, $id_peca);
      $stmt->execute();
      if ($stmt->affected_rows > 0) {
          $_SESSION["msg"] = "Os dados da peça {$nome} foram alterados!";
          $_SESSION["tipo_msg"] = "alert-warning";
      } else {
          $_SESSION["msg"] = "Os dados da peça {$nome} não foram alterados! Erro:" . mysqli_error($conexao);
          $_SESSION["tipo_msg"] = "alert-danger";
      }    
      $stmt->close();
      $conexao->close(); 
    }

    Function AlterarPecaEmp($nome, $quantidade, $cod, $data, $custo, $custof, $lucro, $lucrof, $id_peca, $id_empresa){
      $sql = "UPDATE Estoque_Empresa 
              SET nome_peca = ?, quantidade = ?, cod_peca = ?, data_atualizacao = ?, custo_peca = ?, custo_estoque = ?, lucro_peca = ?, lucro_peca_final = ?
              WHERE id_peca_emp = ? AND id_empresa = ?";            
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("sissiiiiii", $nome, $quantidade, $cod, $data, $custo, $custof, $lucro, $lucrof, $id_peca, $id_empresa);
      $stmt->execute();
      if ($stmt->affected_rows > 0) {
          $_SESSION["msg"] = "Os dados da peça {$nome} foram alterados!";
          $_SESSION["tipo_msg"] = "alert-warning";
      } else {
          $_SESSION["msg"] = "Os dados da peça {$nome} não foram alterados! Erro:" . mysqli_error($conexao);
          $_SESSION["tipo_msg"] = "alert-danger";
      }    
      $stmt->close();
      $conexao->close(); 
    }

    function buscarPecaAdm($id_peca_adm) {
      $sql = "SELECT * FROM Estoque_Admin WHERE id_peca_admin = ?";
      $conexao = obterConexao();
      $stmt = $conexao->prepare($sql);
      $stmt->bind_param("i", $id_peca_adm);
      $stmt->execute();
      $resultado = $stmt->get_result();
      $pecaAdm = mysqli_fetch_assoc($resultado);
      $stmt->close();
      $conexao->close();
      return $pecaAdm;
      }

      function buscarPecaEmp($id_peca_emp, $id_empresa) {
        $sql = "SELECT * FROM Estoque_Empresa WHERE id_peca_emp = ? AND id_empresa = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id_peca_emp, $id_empresa);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $pecaEmp = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $pecaEmp;
      }

      function ListarEmpresas(){
        $lista_emp = [];
        $sql = "SELECT * FROM Empresa";  
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($empresas = mysqli_fetch_assoc($resultado)) {
          array_push($lista_emp, $empresas);
        }
        $stmt->close();
        $conexao->close();
        return $lista_emp;
      }

      function MostrarOrdemServico($id_empresa){
        $lista_ordem_servico = [];
        $sql = "SELECT o.id_os, s.situacao_descricao, v.modelo_veiculo, v.placa_veiculo, c.nome_cliente_empresa
                FROM Ordem_Servico o
                INNER JOIN ClienteEmpresa c ON o.id_cliente_empresa = c.id_cliente_empresa
                INNER JOIN Veiculos v ON o.id_veiculo = v.id_veiculo
                INNER JOIN Situacao s ON o.id_situacao = s.id_situacao
                WHERE o.id_empresa = ?";  
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id_empresa);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($os = mysqli_fetch_assoc($resultado)) {
          array_push($lista_ordem_servico, $os);
        }
        $stmt->close();
        $conexao->close();
        return $lista_ordem_servico;
      }

        function ListarServicos($id_empresa){
          $lista_servico = [];
          $sql = "SELECT w.id_servico, s.situacao_descricao, v.modelo_veiculo, v.placa_veiculo, c.nome_cliente_empresa, w.descricao_problema_cliente, w.modificacoes_servico
                  FROM Servicos w
                  INNER JOIN ClienteEmpresa c ON w.id_cliente_empresa = c.id_cliente_empresa
                  INNER JOIN Situacao s ON w.id_situacao = s.id_situacao 
                  INNER JOIN Veiculos v ON w.id_veiculo = v.id_veiculo
                  WHERE w.id_empresa = ? AND w.id_situacao = 2";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("i", $id_empresa);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($servico = mysqli_fetch_assoc($resultado)) {
            array_push($lista_servico, $servico);
          }
          $stmt->close();
          $conexao->close();
          return $lista_servico;
        }

        function ListarServicosCliente($id_cliente_emp){
          $lista_servico = [];
          $sql = "SELECT w.id_servico, s.situacao_descricao, v.modelo_veiculo, v.placa_veiculo, e.nome_empresa, w.descricao_problema_cliente, w.modificacoes_servico
                  FROM Servicos w
                  INNER JOIN Empresa e ON w.id_empresa = e.id_empresa
                  INNER JOIN Situacao s ON w.id_situacao = s.id_situacao 
                  INNER JOIN Veiculos v ON w.id_veiculo = v.id_veiculo
                  WHERE w.id_cliente_empresa = ?";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("i", $id_cliente_emp);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($servico = mysqli_fetch_assoc($resultado)) {
            array_push($lista_servico, $servico);
          }
          $stmt->close();
          $conexao->close();
          return $lista_servico;
        }

        function buscarOs($id_ordem_servico, $id_empresa) {
          $sql = "SELECT * FROM Ordem_Servico WHERE id_os = ? AND id_empresa = ?";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $id_ordem_servico, $id_empresa);
          $stmt->execute();
          $resultado = $stmt->get_result();
          $Os = mysqli_fetch_assoc($resultado);
          $stmt->close();
          $conexao->close();
          return $Os;
        }

        function Nova_Ordem_servico($cliente_emp, $veiculo, $situacao, $id_empresa){
          $sql = "INSERT INTO  Ordem_Servico(id_cliente_empresa, id_veiculo, id_situacao, id_empresa) 
                  VALUES (?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("iiii", $cliente_emp, $veiculo, $situacao, $id_empresa);
          $stmt->execute();
          $stmt->close();
          $conexao->close(); 
        }

        function NovoServico($cliente_emp, $nome, $data, $situacao, $modificacao, $veiculo, $id_empresa){
          $sql = "INSERT INTO Servicos(id_cliente_empresa, data_servico, id_situacao, modificacoes_servico, id_veiculo, id_empresa) 
                  VALUES (?, ?, ?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("isisii", $cliente_emp, $data, $situacao, $modificacao, $veiculo, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "O serviço na empresa {$nome} foi aceito!";
            $_SESSION["tipo_msg"] = "alert-success";
          } else {
            $_SESSION["msg"] = "O serviço na empresa {$nome} não foi aceito! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }
          $stmt->close();
          $conexao->close(); 
        }

        function AlterarServico($cliente, $veiculo, $modificacao, $problema, $id_servico, $id_empresa, $nome){
          $sql = "UPDATE Servicos
                  SET id_cliente_empresa = ?, id_veiculo = ?, modificacoes_servico = ?, descricao_problema_cliente = ?
                  WHERE id_servico = ? AND id_empresa = ?";            
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("iissii", $cliente, $veiculo, $modificacao, $problema, $id_servico, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
              $_SESSION["msg"] = "Os dados do serviço do cliente {$nome} foram alterados!";
              $_SESSION["tipo_msg"] = "alert-warning";
          } else {
              $_SESSION["msg"] = "Os dados do serviço do cliente {$nome} não foram alterados! Erro:" . mysqli_error($conexao);
              $_SESSION["tipo_msg"] = "alert-danger";
          }    
          $stmt->close();
          $conexao->close(); 
        }

        function ListarPecaUtilizadas($id_empresa, $id_servico){
          $lista_peca_utilizada = [];
          $sql = "SELECT e.nome_peca, e.cod_peca, p.quantidade_utilizada, p.id_peca_utilizada
                  FROM Pecas_Utilizadas p
                  INNER JOIN Estoque_Empresa e ON p.id_peca_emp = e.id_peca_emp
                  WHERE p.id_empresa = ? AND p.id_servico = ?";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $id_empresa, $id_servico);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($pecas = mysqli_fetch_assoc($resultado)) {
            array_push($lista_peca_utilizada, $pecas);
          }
          $stmt->close();
          $conexao->close();
          return $lista_peca_utilizada;
        }

        function NovaPecaUtilizadas($id_peca_emp, $quantidade, $id_servico, $id_empresa, $nome){
          $sql = "INSERT INTO Pecas_utilizadas(id_peca_emp, quantidade_utilizada, id_servico, id_empresa) 
                  VALUES (?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("iiii", $id_peca_emp, $quantidade, $id_servico, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "A peça {$nome} foi adicionada!";
            $_SESSION["tipo_msg"] = "alert-success";
        } else {
            $_SESSION["msg"] = "A peça {$nome} não foi adicionada! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
        }  
          $stmt->close();
          $conexao->close(); 
        }

        function removerPecaUtilizada($id_peca_utilizada, $nome, $id_empresa, $id_servico) {
          $sql = "DELETE FROM Pecas_utilizadas
                  WHERE id_peca_utilizada = ? AND id_empresa = ? AND id_servico = ?" ;
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("iii", $id_peca_utilizada, $id_empresa, $id_servico) ;
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "A peça {$nome} foi removida!";
            $_SESSION["tipo_msg"] = "alert-danger";
          } else {
            $_SESSION["msg"] = "A peça {$nome} não foi removida! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }
          $stmt->close();
          $conexao->close();
      } 

        function ListarClientes($id_empresa){
          $lista_clientes = [];
          $sql = "SELECT * FROM ClienteEmpresa WHERE id_empresa = ?";  
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("i", $id_empresa);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($clientes = mysqli_fetch_assoc($resultado)) {
            array_push($lista_clientes, $clientes);
          }
          $stmt->close();
          $conexao->close();
          return $lista_clientes;
        }

        function ListarSituacao(){
          $lista_situacao = [];
          $sql = "SELECT * FROM Situacao";  
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($situacao = mysqli_fetch_assoc($resultado)) {
            array_push($lista_situacao, $situacao);
          }
          $stmt->close();
          $conexao->close();
          return $lista_situacao;
        }

        function ListarVeiculos($id_empresa, $id_cliente_emp){
          $lista_veiculos = [];
          $sql = "SELECT v.id_veiculo, v.modelo_veiculo, v.placa_veiculo, c.nome_cliente_empresa, v.id_cliente_empresa 
                  FROM Veiculos v 
                  INNER JOIN ClienteEmpresa c ON v.id_cliente_empresa = c.id_cliente_empresa
                  INNER JOIN Empresa e ON v.id_empresa = e.id_empresa
                  WHERE v.id_empresa = ? AND v.id_cliente_empresa = ?";  
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $id_empresa, $id_cliente_emp);
          $stmt->execute();
          $resultado = $stmt->get_result();
          while ($veiculos = mysqli_fetch_assoc($resultado)) {
            array_push($lista_veiculos, $veiculos);
          }
          $stmt->close();
          $conexao->close();
          return $lista_veiculos;
        }

        function buscarVeiculo($id_veiculo, $id_empresa) {
          $sql = "SELECT * FROM Veiculos WHERE id_veiculo = ? AND id_empresa = ?";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $id_veiculo, $id_empresa);
          $stmt->execute();
          $resultado = $stmt->get_result();
          $veiculo = mysqli_fetch_assoc($resultado);
          $stmt->close();
          $conexao->close();
          return $veiculo;
        }

        function Novo_veiculo($cliente, $modelo, $placa, $id_empresa, $nome){
          $sql = "INSERT INTO  Veiculos(id_cliente_empresa, modelo_veiculo, placa_veiculo, id_empresa)
                  VALUES (?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("issi", $cliente, $modelo, $placa, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "O veiculo de modelo {$modelo} e placa {$placa} foi adicionado para o cliente {$nome}!";
            $_SESSION["tipo_msg"] = "alert-success";
          } else {
            $_SESSION["msg"] = "Não foi possivel adicionar o veiculo! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }  
          $stmt->close();
          $conexao->close(); 
        }

        Function AlterarVeiculo($cliente, $modelo, $placa, $id_veiculo, $id_empresa, $nome){
          $sql = "UPDATE Veiculos
                  SET id_cliente = ?, modelo_veiculo = ?, placa_veiculo = ?
                  WHERE id_veiculo = ? AND id_empresa = ?";            
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("issii", $cliente, $modelo, $placa, $id_veiculo, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "Os dados do veiculo de modelo {$modelo} e placa {$placa} do cliente {$nome} foi alterado!";
            $_SESSION["tipo_msg"] = "alert-warning";
          } else {
            $_SESSION["msg"] = "Não foi possivel alterar os dados do veiculo! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }  
          $stmt->close();
          $conexao->close(); 
        }

        function NovoCliente($nome, $email, $telefone, $cpf, $id_cliente, $id_empresa){
          $sql = "INSERT INTO ClienteEmpresa(nome_cliente_empresa, email_cliente_empresa, telefone_cliente_empresa, cpf_cliente_empresa, id_cliente, id_empresa)
                  VALUES (?, ?, ?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ssssii", $nome, $email, $telefone, $cpf, $id_cliente, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "O cliente {$nome} foi adicionado como cliente da sua empresa!";
            $_SESSION["tipo_msg"] = "alert-success";
          } else {
            $_SESSION["msg"] = "Não foi possivel adicionar o cliente a sua empresa! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }  
          $stmt->close();
          $conexao->close(); 
        }

        function removerCliente($id, $id_empresa, $nome) {
          $sql = "DELETE FROM ClienteEmpresa 
                  WHERE id_cliente_empresa = ? AND id_empresa = ?" ;
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $id, $id_empresa);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "O cliente {$nome} foi removido!";
            $_SESSION["tipo_msg"] = "alert-danger";
          } else {
            $_SESSION["msg"] = "O cliente {$nome} não foi removido! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }
          $stmt->close();
          $conexao->close();
       }

      function removerVeiculo($id_veiculo, $id_empresa, $modelo, $placa) {
        $sql = "DELETE FROM Veiculos 
                WHERE id_veiculo = ? AND id_empresa = ?" ;
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id_veiculo, $id_empresa);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
          $_SESSION["msg"] = "O veiculo {$modelo} com placa {$placa} foi removido!";
          $_SESSION["tipo_msg"] = "alert-danger";
        } else {
          $_SESSION["msg"] = "O veiculo {$modelo} com placa {$placa} não foi removido! Erro:";
          $_SESSION["tipo_msg"] = "alert-danger";
        }
        $stmt->close();
        $conexao->close();
      } 
      function MostrarDadosEmpresa($id_empresa){
        $dadosEmpresa = [];
        $sql = "SELECT * FROM Empresa WHERE id_empresa = ?";  
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id_empresa);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($empresa = mysqli_fetch_assoc($resultado)) {
            array_push($dadosEmpresa, $empresa);
        }
        $stmt->close();
        $conexao->close();
        return $dadosEmpresa;
    }
    
      function BuscarCliente($cpf){
        $sql = "SELECT nome_cliente, telefone_cliente, email_cliente, id_cliente FROM Cliente WHERE cpf_cliente = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $cpf);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $cliente = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $cliente;
      }

      function Notificacao_novo_servico($id_cliente, $id_empresa, $id_os, $veiculo, $nome){
        $sql = "INSERT INTO notificacao_requisito_servico(id_cliente, id_empresa, id_os, id_veiculo)
                  VALUES (?, ?, ?, ?)";
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("iiii", $id_cliente["id_cliente"], $id_empresa, $id_os["id_os"], $veiculo);
          $stmt->execute();
          if ($stmt->affected_rows > 0) {
            $_SESSION["msg"] = "Uma solicitação de ordem e serviço foi enviada para o cliente {$nome}!";
            $_SESSION["tipo_msg"] = "alert-warning";
          } else {
            $_SESSION["msg"] = "Não foi possivel enviar uma solicitação e ordem de serviço para o cliente! Erro:" . mysqli_error($conexao);
            $_SESSION["tipo_msg"] = "alert-danger";
          }  
          $stmt->close();
          $conexao->close(); 
      }

      function BuscarNotificacao($id_notificacao, $cliente){
        $sql = "SELECT * FROM notificacao_requisito_servico WHERE id_notificacao = ? AND id_cliente = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id_notificacao, $cliente);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $notificacao = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $notificacao;
      }

      function BuscarClient($cliente_emp){
        $sql = "SELECT id_cliente, nome_cliente_empresa FROM ClienteEmpresa WHERE id_cliente_empresa = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $cliente_emp);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $cliente = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $cliente;
      }

      function buscarServico($id_servico, $id_empresa){
        $sql = "SELECT * FROM Servicos WHERE id_servico = ? AND id_empresa = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $id_servico, $id_empresa);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $servico = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $servico;
      }

      function RemoverNotificacao($id_notificacao, $cliente){
        $sql = "DELETE FROM notificacao_requisito_servico
                WHERE id_cliente = ? AND id_notificacao = ?" ;
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("ii", $cliente, $id_notificacao);
          $stmt->execute();
          $stmt->close();
          $conexao->close();
      }

      function RemoverOs($id_os){
        $sql = "DELETE FROM Ordem_Servico
                WHERE id_os = ?" ;
          $conexao = obterConexao();
          $stmt = $conexao->prepare($sql);
          $stmt->bind_param("i", $id_os);
          $stmt->execute();
          $stmt->close();
          $conexao->close();
      }

      function BuscarClienteEmpresa($id_cliente){
        $sql = "SELECT id_cliente_empresa FROM ClienteEmpresa WHERE id_cliente = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $id_cliente);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $id_cliente_emp = mysqli_fetch_assoc($resultado);
        $stmt->close();
        $conexao->close();
        return $id_cliente_emp;
      }
