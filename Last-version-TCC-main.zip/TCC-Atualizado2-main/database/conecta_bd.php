<?php
    function ObterConexao(){
    $servidor = "localhost";
    $usuario = "root";
    $senha = "";
    $banco = "grupo6";

    $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

    if (!$conexao) {
        echo "Não foi possível conectar ao banco de dados! Erro: " . mysqli_connect_error();
        die();  
    }

    return($conexao);
    } 
    

?>