DROP DATABASE IF EXISTS grupo6;
CREATE DATABASE grupo6;
USE grupo6;

CREATE TABLE Tipo_Usuario(
id_tipo_usuario INT AUTO_INCREMENT,
tipo VARCHAR(255) NOT NULL,
PRIMARY KEY(id_tipo_usuario)
);

INSERT INTO 
Tipo_Usuario(tipo)
VALUES
("Administrador"),
("Empresa"),
("Cliente");

CREATE TABLE Administrador(
id_admin INT AUTO_INCREMENT, 
nome_admin VARCHAR(255) NOT NULL,
email_admin VARCHAR(255) NOT NULL, 
senha_admin VARCHAR(255) NOT NULL,
id_tipo_usuario INT,
PRIMARY KEY(id_admin),
FOREIGN KEY (id_tipo_usuario) REFERENCES Tipo_Usuario(id_tipo_usuario)
);

CREATE TABLE Cliente(
id_cliente INT AUTO_INCREMENT,
nome_cliente VARCHAR(255) NOT NULL,
telefone_cliente VARCHAR(14) NOT NULL,
email_cliente VARCHAR(255) NOT NULL,
senha_cliente VARCHAR(255) NOT NULL,
cpf_cliente VARCHAR(14) NOT NULL,
imagem_cliente VARCHAR(255) NULL,
id_tipo_usuario INT,
PRIMARY KEY (id_cliente),
FOREIGN KEY (id_tipo_usuario) REFERENCES Tipo_Usuario(id_tipo_usuario)
);

CREATE TABLE Empresa(
id_empresa INT AUTO_INCREMENT,
nome_empresa VARCHAR(255) NOT NULL,
endereco_empresa VARCHAR(255) NOT NULL,
telefone_empresa VARCHAR(255) NOT NULL,
email_empresa VARCHAR(255) NOT NULL,
senha_empresa VARCHAR(255) NOT NULL,
cnpj_empresa VARCHAR(18) NOT NULL,
imagem_empresa VARCHAR(255) NULL,
id_tipo_usuario INT,
PRIMARY KEY(id_empresa),
FOREIGN KEY (id_tipo_usuario) REFERENCES Tipo_Usuario(id_tipo_usuario)
);


INSERT INTO 
Administrador(nome_admin, email_admin, senha_admin, id_tipo_usuario)
VALUES
("admin", "automecanica@gmail.com", MD5("batata"), 1);

INSERT INTO 
Empresa(nome_empresa, endereco_empresa, telefone_empresa, email_empresa, senha_empresa, cnpj_empresa, id_tipo_usuario)
VALUES
("Empresa 1", "rua 14", "(16)99999-9999", "empresa1@gmail.com", MD5("empresa1"), "10.584.158/0001-36", 2);

INSERT INTO
Cliente(nome_cliente, telefone_cliente, email_cliente, senha_cliente, cpf_cliente, id_tipo_usuario)
VALUES
("Cliente 1", "(16)99614-2354", "cliente1@gmail.com", MD5("cliente1"), "111.111.111-11", 3);

CREATE TABLE Usuario(
id_usuario INT AUTO_INCREMENT,
id_referencia INT NOT NULL,
nome_usuario VARCHAR(255) NOT NULL,
email_usuario VARCHAR(255) NOT NULL,
senha_usuario VARCHAR(255) NOT NULL,
chave_senha_recuperar VARCHAR(255) NULL,
id_tipo_usuario INT,
PRIMARY KEY(id_usuario),
FOREIGN KEY(id_tipo_usuario) REFERENCES Tipo_Usuario(id_tipo_usuario)
);

INSERT INTO 
Usuario(id_referencia, nome_usuario,email_usuario, senha_usuario, id_tipo_usuario)
VALUES
(1, "Admin","automecanica@gmail.com", MD5("batata"), 1),
(1, "Empresa 1","empresa1@gmail.com", MD5("empresa1"), 2),
(1, "Cliente 1","cliente1@gmail.com", MD5("cliente1"), 3);

CREATE TABLE Estoque_Empresa(
id_peca_emp INT AUTO_INCREMENT,
cod_peca VARCHAR(255) NOT NULL,
nome_peca VARCHAR(255) NOT NULL,
quantidade INT(255) NOT NULL,
data_atualizacao DATE NOT NULL,
custo_peca DECIMAL(10,2) NOT NULL,
custo_estoque DECIMAL(10,2) NOT NULL,
lucro_peca INT(255) NOT NULL,
lucro_peca_final DECIMAL(10,2) NOT NULL,
id_empresa INT,
PRIMARY KEY(id_peca_emp),
FOREIGN KEY(id_empresa) REFERENCES Empresa(id_empresa)
);

CREATE TABLE Estoque_Admin(
id_peca_admin INT AUTO_INCREMENT,
nome_peca VARCHAR(255) NOT NULL,
cod_peca VARCHAR(255) NOT NULL,
PRIMARY KEY(id_peca_admin)
);

INSERT INTO Estoque_Admin (nome_peca, cod_peca)
VALUES
  ("parafuso", 1), ("porca", 2), ("farol", 3), ("pneu", 4), ("bobina", 5),
  ("filtro de óleo", 6), ("bateria", 7), ("amortecedor", 8), ("pastilha de freio", 9), ("disco de freio", 10),
  ("sensor de temperatura", 11), ("vela de ignição", 12), ("correia dentada", 13), ("óleo de motor", 14), ("radiador", 15),
  ("junta do cabeçote", 16), ("catalisador", 17), ("embreagem", 18), ("radiador de óleo", 19), ("rolamento", 20),
  ("sensor de oxigênio", 21), ("mangueira de radiador", 22), ("bomba de combustível", 23), ("interruptor de luz", 24), ("motor de partida", 25),
  ("bomba de água", 26), ("cilindro mestre de freio", 27), ("sensor de posição da borboleta", 28), ("suspensão a ar", 29), ("junta homocinética", 30),
  ("coletor de escape", 31), ("mangueira de freio", 32), ("compressor de ar condicionado", 33), ("pistão", 34), ("anéis do pistão", 35),
  ("retentor de válvula", 36), ("bico injetor", 37), ("sensor de ABS", 38), ("reservatório de expansão", 39), ("rolamento de roda", 40);


CREATE TABLE ClienteEmpresa(
id_cliente_empresa INT AUTO_INCREMENT,
nome_cliente_empresa VARCHAR(255) NOT NULL,
email_cliente_empresa VARCHAR(255) NOT NULL,
telefone_cliente_empresa VARCHAR(16) NOT NULL,
cpf_cliente_empresa VARCHAR(14) NOT NULL,
id_cliente INT,
id_empresa INT,
PRIMARY KEY (id_cliente_empresa),
FOREIGN KEY(id_cliente) REFERENCES Cliente(id_cliente),
FOREIGN KEY(id_empresa) REFERENCES Empresa(id_empresa)
);

INSERT INTO
ClienteEmpresa(nome_cliente_empresa, email_cliente_empresa, telefone_cliente_empresa, cpf_cliente_empresa, id_cliente, id_empresa)
VALUES
("Cliente 1", "cliente1@gmail.com","(16)99999-7548", "111.111.111-11", 1, 1);

CREATE TABLE Veiculos(
id_veiculo INT AUTO_INCREMENT,
modelo_veiculo VARCHAR(255) NOT NULL,
placa_veiculo VARCHAR(7) NOT NULL,
id_cliente_empresa INT,
id_empresa INT,
PRIMARY KEY(id_veiculo),
FOREIGN KEY(id_empresa) REFERENCES Empresa(id_empresa),
FOREIGN KEY(id_cliente_empresa) REFERENCES ClienteEmpresa(id_cliente_empresa)
);

INSERT INTO 
Veiculos(modelo_veiculo, placa_veiculo, id_cliente_empresa, id_empresa)
VALUES
("Civic", "G91MND3", 1,1);

CREATE TABLE Situacao(
id_situacao INT AUTO_INCREMENT,
situacao_descricao VARCHAR(30) NOT NULL,
PRIMARY KEY(id_situacao)
); 

INSERT INTO
Situacao (situacao_descricao)
VALUES
("Concluido"),
("Em andamento"),
("Aguardando Confirmação"),
("Recusado");

CREATE TABLE Servicos(
id_servico INT AUTO_INCREMENT,
id_cliente_empresa INT,
data_servico DATE NOT NULL,
id_situacao INT,
modificacoes_servico VARCHAR(255) NOT NULL,
descricao_problema_cliente VARCHAR(255),
id_veiculo INT,
id_empresa INT,
PRIMARY KEY(id_servico),
FOREIGN KEY(id_cliente_empresa) REFERENCES ClienteEmpresa(id_cliente_empresa),
FOREIGN KEY (id_situacao) REFERENCES Situacao(id_situacao),
FOREIGN KEY(id_empresa) REFERENCES Empresa(id_empresa),
FOREIGN KEY (id_veiculo) REFERENCES Veiculos(id_veiculo)
);

CREATE TABLE Pecas_utilizadas(
  id_peca_utilizada INT AUTO_INCREMENT,
  quantidade_utilizada INT NOT NULL,
  id_peca_emp INT,
  id_servico INT,
  id_empresa INT,
  PRIMARY KEY(id_peca_utilizada),
  FOREIGN KEY(id_peca_emp) REFERENCES Estoque_Empresa(id_peca_emp),
  FOREIGN KEY(id_empresa) REFERENCES Empresa(id_empresa),
  FOREIGN KEY(id_servico) REFERENCES Servicos(id_servico)
);

CREATE TABLE Ordem_Servico(
  id_os INT AUTO_INCREMENT,
  id_situacao INT,
  id_veiculo INT,
  id_cliente_empresa INT,
  id_empresa INT,
  PRIMARY KEY(id_os),
  FOREIGN KEY (id_cliente_empresa) REFERENCES ClienteEmpresa(id_cliente_empresa),
  FOREIGN KEY (id_empresa) REFERENCES Empresa(id_empresa),
  FOREIGN KEY (id_situacao) REFERENCES Situacao(id_situacao),
  FOREIGN KEY (id_veiculo) REFERENCES Veiculos(id_veiculo)
  );

  CREATE TABLE notificacao_requisito_servico (
    id_notificacao INT AUTO_INCREMENT,
    id_cliente INT,
    id_empresa INT,
    id_os INT,
    id_veiculo INT,
    PRIMARY KEY (id_notificacao),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_empresa) REFERENCES Empresa(id_empresa),
    FOREIGN KEY (id_os) REFERENCES Ordem_Servico(id_os),
    FOREIGN KEY (id_veiculo) REFERENCES Veiculos(id_veiculo)
);
