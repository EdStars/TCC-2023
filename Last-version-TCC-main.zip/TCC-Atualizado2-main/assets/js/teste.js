function esconderSenha() {
  let pwd = document.getElementById("id_senha");
  if (pwd.type === "password") {
      pwd.type = "text";
  } else {
      pwd.type = "password";
  }
}