// Aplicar máscara de CPF
$('#cpf').inputmask('999.999.999-99');

// Aplicar máscara de CNPJ
$('#cnpj').inputmask('99.999.999/9999-99');
