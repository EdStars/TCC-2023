var dropdown = document.getElementById("DropdownHome");

dropdown.addEventListener("mouseenter", function(event) {
  event.target.classList.add("show");
  event.target.querySelector(".dropdown-menu").classList.add("show");
});

dropdown.addEventListener("mouseleave", function(event) {
  event.target.classList.remove("show");
  event.target.querySelector(".dropdown-menu").classList.remove("show");
})