var currentPage = 1;
var rowsPerPage = 8;
var table = document.getElementById("tabela_estoque");
var rows = table.getElementsByTagName("tbody")[0].getElementsByTagName("tr");
var totalPages = Math.ceil((rows.length - 1) / rowsPerPage);

function showPage(page) {
    for (var i = 1; i < rows.length; i++) {
        rows[i].style.display = "none";
    }
    var start = (page - 1) * rowsPerPage + 1;
    var end = start + rowsPerPage - 1;
    for (var j = start; j <= end; j++) {
        if (rows[j]) {
            rows[j].style.display = "table-row";
        }
    }
}

function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
}

function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        showPage(currentPage);
    }
}

showPage(currentPage);