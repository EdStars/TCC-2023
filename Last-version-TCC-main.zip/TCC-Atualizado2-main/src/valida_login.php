<?php
if(!isset($_SESSION["usuario_logado"])){
    session_start();
}

require("../database/usuario_bd.php");


$email = $_POST["email"];
$senha = $_POST["senha"];

$dados_consulta = buscarUsuario($email, $senha);

switch($dados_consulta[0]["id_tipo_usuario"]){
    case 1:
        $dados_consulta = buscarUsuarioAdmin($email, $senha);
        break;
    case 2:
        $dados_consulta = buscarUsuarioEmpresa($email, $senha);
        break;
    case 3:
        $dados_consulta = buscarUsuarioCliente($email, $senha);
        break;
    case NULL:
        break;
}

$usuario = $dados_consulta[0];


if($usuario == null){
    $saida = ["autenticado" => false, "msg" => $dados_consulta[1]];
}else {
    $saida = ["autenticado" => true, "tipo"=>$usuario["id_tipo_usuario"]];
    switch($usuario["id_tipo_usuario"]){
        case 1:
            $_SESSION["usuario_logado"] = $usuario;
            break;
        case 2:
            $_SESSION["usuario_logado"] = $usuario;
            break;
        case 3:
            $_SESSION["usuario_logado"] = $usuario;
            break;
    }
}

$json = json_encode($saida);
echo $json;
?>