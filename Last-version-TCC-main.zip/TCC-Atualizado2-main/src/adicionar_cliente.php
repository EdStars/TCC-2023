<?php
    session_start();
    require("../database/funcoes.php");


    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
    $cpf = $_POST["cpf"];
    $id_cliente = $_POST["id_cliente"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];

    NovoCliente($nome, $email, $telefone, $cpf, $id_cliente, $id_empresa);
    header("Location: ../private/listar_clientes.php");
    exit();
?>