<?php
    session_start();
    require("../database/usuario_bd.php");



    $id_tipo_usuario = 3;
    $cpf = $_POST["cpf"];
    $nome = $_POST["nome"];
    $telefone = $_POST["telefone"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $imagem = NULL;
    
    CriarCliente($nome, $cpf, $telefone, $email, $senha, $imagem, $id_tipo_usuario);
    $usuario = buscarUsuarioCliente($email,$senha);
    
    $id_referencia = $usuario[0]["id_cliente"];

    CriarUsuario($nome, $id_referencia, $email, $senha, $id_tipo_usuario);
    header("Location: ../private/login.php");
?>