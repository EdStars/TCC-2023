<?php
    require("../database/funcoes.php");

    $nome = $_POST["nome_peca"];
    $cod = $_POST["cod_peca"];

    InserirPecaAdm($nome, $cod);
    header("Location: ../private/estoque_adm.php");
?>