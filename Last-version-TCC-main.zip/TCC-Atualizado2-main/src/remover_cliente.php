<?php
    session_start();
    require("../database/funcoes.php");

    $id = $_POST["id"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $nome = $_POST["nome"];

    removerCliente($id, $id_empresa, $nome);
    header("Location: ../private/listar_clientes.php");
?>

