<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];

    require("../database/funcoes.php");

    $cliente_emp = $_POST["cliente"];
    $veiculo = $_POST["veiculo"];
    $situacao = 3;
    $cliente = BuscarClient($cliente_emp);
    $nome = $cliente["nome_cliente_empresa"];

    Nova_Ordem_servico($cliente_emp, $veiculo, $situacao, $id_empresa);

    $sql = "SELECT id_os FROM Ordem_Servico WHERE id_cliente_empresa = ? AND id_empresa = ? AND id_veiculo = ?";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("iii", $cliente_emp, $id_empresa, $veiculo);
    if($stmt->execute()){
        $resultado = $stmt->get_result();
        $id_os = mysqli_fetch_assoc($resultado);
        $sql = "SELECT id_cliente FROM ClienteEmpresa WHERE id_cliente_empresa = ? AND id_empresa = ?";
        $conexao = obterConexao();
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ii", $cliente_emp, $id_empresa);
        if($stmt->execute()){
            $resultado = $stmt->get_result();
            $id_cliente = mysqli_fetch_assoc($resultado);
            Notificacao_novo_servico($id_cliente, $id_empresa, $id_os, $veiculo, $nome);
            $stmt->close();
            $conexao->close();
        }else{
            echo "Erro! no if 2";
        }
    }else{
        echo "Erro! no if 1";
    }
    
        
    
    
    header("Location: ../private/listar_servico.php");
?>