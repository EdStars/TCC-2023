<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    require("../database/funcoes.php");

    $id_servico = $_POST["id_servico"];
    $id_peca_emp = $_POST["peca"];
    $quantidade = $_POST["quantidade"];

    $sql = "SELECT nome_peca 
            FROM Estoque_Empresa
            WHERE id_empresa = ? AND id_peca_emp = ?";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ii", $id_empresa, $id_peca_emp);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $nome_array = mysqli_fetch_assoc($resultado);
    $stmt->close();
    $conexao->close();
    $nome = $nome_array["nome_peca"];

    NovaPecaUtilizadas($id_peca_emp, $quantidade, $id_servico, $id_empresa, $nome);
    header("Location: ../private/formulario_servico_alterar.php?id_servico=$id_servico");
?>

