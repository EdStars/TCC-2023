<?php
    session_start();
    require("../database/usuario_bd.php");

    $id_tipo_usuario = 2;
    $cnpj = $_POST["cnpj"];
    $nome = $_POST["nome"];
    $endereco = $_POST["endereco"];
    $telefone = $_POST["telefone"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $imagem = NULL;

    CriarEmpresa($nome, $cnpj, $endereco, $telefone, $email, $senha, $imagem, $id_tipo_usuario);

    $usuario = buscarUsuarioEmpresa($email,$senha);
    
    $id_referencia = $usuario[0]["id_empresa"];

    CriarUsuario($nome, $id_referencia, $email, $senha, $id_tipo_usuario);
    header("Location: ../private/login.php");
?>