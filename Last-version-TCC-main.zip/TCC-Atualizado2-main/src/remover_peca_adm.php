<?php
    require("../database/funcoes.php");

    $id_peca = $_POST["id"];
    $nome = $_POST["nome"];

    removerPecaAdm($id_peca, $nome);

    header("Location: ../private/estoque_adm.php");
?>

