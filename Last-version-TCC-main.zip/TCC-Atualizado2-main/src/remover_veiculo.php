<?php
    session_start();
    require("../database/funcoes.php");

    $id_veiculo = $_POST["id"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $modelo = $_POST["modelo"];
    $placa = $_POST["placa"];

    removerVeiculo($id_veiculo, $id_empresa, $modelo, $placa);
    header("Location: ../private/listar_clientes.php");
?>

