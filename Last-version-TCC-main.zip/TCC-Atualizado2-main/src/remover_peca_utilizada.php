<?php
    session_start();
    require("../database/funcoes.php");

    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $id_servico = $_POST["id_servico"];
    $id_peca_utilizada = $_POST["id"];
    $nome = $_POST["nome"];

    removerPecaUtilizada($id_peca_utilizada, $nome, $id_empresa, $id_servico);
    header("Location: ../private/formulario_servico_alterar.php?id_servico=$id_servico");
?>

