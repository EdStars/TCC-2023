<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];

    require("../database/funcoes.php");


    $nome = $_POST["nome_peca"];
    $cod = $_POST["cod_peca"];
    $quantidade = $_POST["quantidade"];
    $data = $_POST["data"];
    $custo = $_POST["custo"];
    $custof = $custo * $quantidade;
    $lucro = $_POST["lucro"];
    $lucrof = ($lucro/100) * $custo ;
    $lucrof = str_replace(",", ".", $lucrof);
    InserirPecaEmp($nome, $cod, $quantidade, $data, $custo, $custof, $lucro, $lucrof, $id_empresa);
    header("Location: ../private/estoque_emp.php");
?>