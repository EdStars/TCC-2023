<?php 
    $usuario = $_POST["tipo_usuario"];

    if($usuario==2){
        header("Location: ../src/registro_empresa.php");
    }else{
        header("Location: ../src/registro_cliente.php");
    }
?>