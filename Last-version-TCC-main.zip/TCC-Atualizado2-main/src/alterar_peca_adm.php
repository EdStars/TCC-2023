<?php
    require("../database/funcoes.php");

    $id_peca = $_POST["id_peca"];
    $nome = $_POST["nome_peca"];
    $cod = $_POST["cod_peca"];


    AlterarPecaAdm($id_peca, $nome, $cod);
    header("Location: ../private/estoque_adm.php");
?>