<?php 
include("../database/conecta_bd.php");
require("../database/funcoes.php");
session_start();

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../index.php");
    exit();  // Adiciona um exit para garantir que o código pare de ser executado após o redirecionamento
}

$id_notificacao = $_GET["id_notificacao"];
$cliente = $_SESSION["usuario_logado"]["id_cliente"];
$notificacao = BuscarNotificacao($id_notificacao, $cliente);
$veiculo = $notificacao["id_veiculo"];
$id_empresa = $notificacao["id_empresa"];
$id_os = $notificacao["id_os"];
$data = date('Y-m-d');
$situacao = 2;
$modificacao = "Ainda não houve nenhuma alteração no carro!";

$sql = "SELECT nome_empresa FROM Empresa WHERE id_empresa = ?";
$conexao = obterConexao();
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $id_empresa);
$stmt->execute();
$resultado = $stmt->get_result();
$nome_array = mysqli_fetch_assoc($resultado);
$stmt->close();
$conexao->close();
$nome = $nome_array["nome_empresa"];


$sql = "SELECT id_cliente_empresa FROM ClienteEmpresa WHERE id_empresa = ? AND id_cliente = ?";
$conexao = obterConexao();
$stmt = $conexao->prepare($sql);
$stmt->bind_param("ii", $id_empresa, $cliente);
if ($stmt->execute()) {
    $resultado = $stmt->get_result();
    $cliente_emp_array = mysqli_fetch_assoc($resultado);
    $cliente_emp = $cliente_emp_array["id_cliente_empresa"];
    NovoServico($cliente_emp, $nome, $data, $situacao, $modificacao, $veiculo, $id_empresa);
    RemoverNotificacao($id_notificacao, $cliente);
    RemoverOs($id_os);
    $stmt->close();
    $conexao->close();
} else {
    echo "Erro ao executar a consulta SQL.";  // Adiciona um echo para imprimir a mensagem de erro
}

header("Location: ../private/perfil_usuario.php");
exit();  // Adiciona um exit para garantir que o código pare de ser executado após o redirecionamento
?>
