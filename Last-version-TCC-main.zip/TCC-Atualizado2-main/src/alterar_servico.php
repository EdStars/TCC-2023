<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    require("../database/funcoes.php");

    $id_servico = $_POST["id_servico"];
    $cliente = $_POST["cliente"];
    $veiculo = $_POST["veiculo"];
    $problema = $_POST["descricao_problema_cliente"];
    $modificacao = $_POST["modificacoes"];

    $sql = "SELECT c.nome_cliente_empresa 
            FROM Servicos s 
            INNER JOIN ClienteEmpresa c ON s.id_cliente_empresa = c.id_cliente_empresa
            WHERE s.id_cliente_empresa = ? AND s.id_servico = ?";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ii", $cliente, $id_servico);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $nome_array = mysqli_fetch_assoc($resultado);
    $stmt->close();
    $conexao->close();
$nome = $nome_array["nome_cliente_empresa"];
    AlterarServico($cliente, $veiculo, $modificacao, $problema, $id_servico, $id_empresa, $nome);
    header("Location: ../private/listar_servico.php");
?>