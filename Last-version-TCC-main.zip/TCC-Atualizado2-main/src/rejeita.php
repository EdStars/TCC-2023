<?php 
include("../database/conecta_bd.php");
require("../database/funcoes.php");
session_start();

if (!isset($_SESSION["usuario_logado"])) {
    header("Location: ../index.php");
    exit();  // Adiciona um exit para garantir que o código pare de ser executado após o redirecionamento
}

$id_notificacao = $_GET["id_notificacao"];
$cliente = $_SESSION["usuario_logado"]["id_cliente"];
$notificacao = BuscarNotificacao($id_notificacao, $cliente);
$veiculo = $notificacao["id_veiculo"];
$id_empresa = $notificacao["id_empresa"];
$id_os = $notificacao["id_os"];
$data = date('Y-m-d');
$situacao = 4;

$sql = "SELECT id_cliente_empresa FROM ClienteEmpresa WHERE id_empresa = ? AND id_cliente = ?";
$conexao = obterConexao();
$stmt = $conexao->prepare($sql);
$stmt->bind_param("ii", $notificacao["id_empresa"], $cliente);
if ($stmt->execute()) {
    $resultado = $stmt->get_result();
    RemoverNotificacao($id_notificacao, $cliente);
    AlterarOs($situacao, $id_os, $id_empresa);
    $stmt->close();
    $conexao->close();
} else {
    echo "Erro ao executar a consulta SQL.";  // Adiciona um echo para imprimir a mensagem de erro
}

header("Location: ../private/perfil_usuario.php");
exit();  // Adiciona um exit para garantir que o código pare de ser executado após o redirecionamento
?>
