<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Adicionando o arquivo de estilo do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/extras.js"></script>
     <!-- Titulo da Página -->
    <title>AutoMecânica</title> 

</head>
<body>   
 <div class="inicio shadow-5-strong">
  <!-- Inicio da Barra de Navegação -->
  <nav class="navbar navbar-expand-lg bgcimento navbar-dark bg-dark shadow-5-strong">
    <div class="container">
    <a class="navbar-brand ml-3 shadow-3-strong" href="../public/home.php"><img src="../assets/img/logo.png" widht="50" height="50"></a>
      <button class="navbar-toggler mr-4" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span><i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
             <div class="dropdown" id="DropdownHome">
                 <a class="nav-link text-decoration-none shadow-3-strong btn btn-sm ml-1 mr-1" href="../private/login.php"><i class="fa-solid fa-house"></i> Entrar</a>
             <div class="dropdown-menu bg-dark p-2">
             <form action="../src/valida_login.php" method="POST">
             <div class="form-group">
                        <label class="text-white" for="id_email">Email:</label>
                        <input class="form-control" type="email" id="id_email" placeholder="Digite seu Email" name="email">
                        
                     
                         <label class="text-white" for="id_senha">Senha:</label>
                          <div class="input-group">
                              <input class="form-control" type="password" id="id_senha" placeholder="Insira sua senha" name="senha" aria-describedby="button-addon2">      
                        </div>
             </form>
             <button class="btn-sm btn-primary btn-block mt-2 shadow-5-strong" type="button" id="id_btn_login" name="btn_login">Entrar <i class="fa-solid fa-right-to-bracket"></i></button> 
               </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm nav-link ml-1 shadow-3-strong mr-1" href="../private/registro.php"><i class="fa-solid fa-car"></i> Cadastre-se</a>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm nav-link ml-1 shadow-3-strong mr-1" href="#"><i class="mx-1 fa-solid fa-phone"></i>Contate-nos</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>  
  <!-- Fim da Barra de Navegação -->   

 <!-- Inicio do Login-->   
 <div id="registro" name="login">  
      <section class="gradient-custom">
        <div class="container mt-3">
          <div class="row justify-content-center align-items-center">
             <div class="col-md-8 card shadow-2-strong card-registration card bg-dark ">
             <a class="text-white text-decoration-none shadow-3-lg mt-2 btn btn-lg p-3" href="../private/login.php"><i class="fas fa-circle-arrow-left"></i> Voltar</a>
               <h5 class="text-center mb-2 mt-3 mr-2 ml-2 text-white"><i class="mx-1 fa-solid fa-users"></i>Recuperação de Senha - <b>AutoMecânica</b> <i class="fas fa-users-gear"></i></h5>
                   <div class="card-body p-4 p-md-5">
                     <form action="../src/novo_usuario_empresa.php" method="POST" class="text-white shadow-3-lg">
              <div class="row">
                <div class="col-md-12 mb-3">
                  <div class="">
                      <label for="email" class="form-label text-white bg-dark rounded mt-1">Email</label>
                      <input class="form-control form-item" type="email" placeholder="Insira o email já cadastrado" id="id_email" name="email">
                  </div>
              <small id="tip" class="form-text text-center text-muted mb-2">Nunca compartilhe suas informações pessoais!</small>
                  
                  <div class="form-group checkbox mt-2 mb-3">
                      <div class="text-center text-danger" id="id_msg"></div>
                  </div>
                 
                  <div class="form-group px-5 text-center">
                        <input class="btn btn-lg btn-primary shadow-5-strong"  name="enviar" value="Enviar Código" placeholder="Enviar Código" type="submit">
                  </div>
                </form>
                </div>
               </div>
              </div>
            </div>
           </div>
        </section>
      </div>
     </div>
  </div> 
</div>
  <!-- Adicionando o arquivo de script do Bootstrap e do FontAweasome -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"  crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/da85f6d2d9.js" crossorigin="anonymous"></script>

 </div>
</body>
<html>







