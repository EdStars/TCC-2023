<?php
    session_start();
    require("../database/funcoes.php");

    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $cliente = $_POST["cliente"];
   
    $modelo = $_POST["modelo"];
    $placa = $_POST["placa_veiculo"];
   

    $sql = "SELECT c.nome_cliente_empresa 
            FROM Veiculos v
            INNER JOIN ClienteEmpresa c ON v.id_cliente_empresa = c.id_cliente_empresa
            WHERE v.id_cliente_empresa = ? AND v.id_empresa = ? ";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ii", $cliente, $id_empresa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $nome_array = mysqli_fetch_assoc($resultado);
    $stmt->close();
    $conexao->close();
    $nome = $nome_array["nome_cliente_empresa"];
 

    Novo_veiculo($cliente, $modelo, $placa, $id_empresa, $nome);
    header("Location:../private/listar_clientes.php");
?>