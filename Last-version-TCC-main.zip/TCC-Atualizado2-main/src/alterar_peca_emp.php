<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];

    require("../database/funcoes.php");

    $id_peca = $_POST["id_peca"];
    $cod = $_POST["cod_peca"];
    $nome = $_POST["nome_peca"];
    $quantidade = $_POST["quantidade"];
    $data = $_POST["data"];
    $custo = $_POST["custo"];
    $custof = $custo * $quantidade;
    $lucro = $_POST["lucro"];
    $lucrof = ($lucro/100) * $custo ;
    AlterarPecaEmp($nome, $quantidade, $cod, $data, $custo, $custof, $lucro, $lucrof, $id_peca, $id_empresa);
    header("Location: ../private/estoque_emp.php");
?>