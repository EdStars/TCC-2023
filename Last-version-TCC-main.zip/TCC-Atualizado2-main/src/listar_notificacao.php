<?php 
      include("../database/conecta_bd.php");
      require("../database/funcoes.php");
      session_start();
      if(!isset($_SESSION["usuario_logado"])){
        header("Location: ../index.php");
      }
      
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
    <!-- Adicionando o arquivo de estilo do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/extras.js"></script>
     <!-- Titulo da Página -->
    <title>AutoMecânica</title> 
</head>
<body>
  
<table class="col-12 table table-hover table-dark">
            <thead class="thead-dark">
                <tr class="text-center">
                    <th scope="col" colspan="2"><i class="fas fa-house-chimney-user"></i>Você requisitou este serviço? </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $lista_notificacoes = [];
                    $id_cliente= $_SESSION["usuario_logado"]["id_cliente"];
                    $sql = "SELECT n.id_notificacao, n.id_empresa, n.id_cliente, e.nome_empresa 
                            FROM notificacao_requisito_servico n
                            INNER JOIN Empresa e
                            ON n.id_empresa = e.id_empresa
                            WHERE n.id_cliente = ?";
              
                    $conexao = obterConexao();
                    $stmt = $conexao->prepare($sql);
                    $stmt->bind_param("i", $id_cliente);
                    $stmt->execute();
                    $resultado = $stmt->get_result();
                    while ($notificacao = mysqli_fetch_assoc($resultado)) {
                      array_push($lista_notificacoes, $notificacao);
                    }
                    $stmt->close();
                    $conexao->close();
                    

                    
                    foreach ($lista_notificacoes as $item) :
                    ?>
                    <tr class="text-center"> 
                      <td><b></b></td>
                      <td>
                         <a class="btn btn-outline-light" href="../src/aceita.php?id_notificacao=<?=$item['id_notificacao']?>"> Sim</a>  
                       </td>
                       <td>
                          <a class="btn btn-outline-light" href="../src/rejeita.php?id_notificacao=<?=$item['id_notificacao']?>"> Não</a>  
                        </td>
                      </tr>  
                <?php
                endforeach
                ?>
                                             
            </tbody>
        </table>
</body>
</html>


