<?php
    session_start();
    require("../database/funcoes.php");

    $id_peca = $_POST["id"];
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    $nome = $_POST["nome"];

    removerPecaEmp($id_peca, $id_empresa, $nome);
    header("Location: ../private/estoque_emp.php");
?>

