<?php
  require("../database/usuario_bd.php");
  Logout();
?>