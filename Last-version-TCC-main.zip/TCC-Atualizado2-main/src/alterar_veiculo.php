<?php
    session_start();
    $id_empresa = $_SESSION["usuario_logado"]["id_empresa"];
    require("../database/funcoes.php");

    $id_veiculo = $_POST["id_veiculo"];
    $cliente = $_POST["cliente"];
    $modelo = $_POST["modelo"];
    $placa = $_POST["placa_veiculo"];

    $sql = "SELECT c.nome_cliente_empresa 
            FROM Veiculos v
            INNER JOIN ClienteEmpresa c ON v.id_cliente_emp = c.id_cliente_emp
            WHERE p.id_veiculo = ? AND p.id_empresa = ? ";
    $conexao = obterConexao();
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ii", $id_veiculo, $id_empresa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $nome = mysqli_fetch_assoc($resultado);
    $stmt->close();
    $conexao->close();


    AlterarVeiculo($cliente, $modelo, $placa, $id_veiculo, $id_empresa);
    header("Location: ../private/listar_veiculos.php");
?>